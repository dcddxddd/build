# Monster Rise（跳劈扩展）

**版本：0.1.2+26.3**  
**目标环境：Minecraft 26.3 / Fabric Loader 0.20.1 / Fabric API 0.166.x / Java 25**

游戏内模组列表显示名称为 **Monster Rise**。为兼容已有配置，内部 mod ID 仍保留为 `leapstrike`，配置文件仍为 `config/leapstrike.json`。

本工程只添加近战敌对生物的“蓄力—跳跃突进—落地范围攻击”。不修改生物基础血量、攻击力、移动速度，不添加精英等级、词条、威胁成长、掉落或新实体。

## 当前实现

- 在 `ServerEntityEvents.ENTITY_LOAD` 中检查实体类型；只给配置名单中的 `Mob` 添加一个原版 AI `Goal`。
- 不进行全世界实体轮询；不对所有实体每 tick 扫描。
- 蓄力时停导航并朝向玩家，默认 10 tick（约 0.5 秒）。
- 跳跃突进：默认水平速度 0.68、垂直速度 0.42，并简单预测玩家短距离移动。
- 落地攻击：默认半径 2.3 格；主目标按原攻击属性造成 1.0 倍伤害，范围内其他可攻击玩家受到 0.35 倍伤害，并产生轻微击退。
- 默认冷却 160 tick（8 秒）。
- **仅在困难（Hard）难度生效**：和平、简单、普通难度不会发动跳劈。
- 如果游戏运行中切换离开困难难度，正在蓄力或空中的跳劈会立即取消；切回困难难度后自动恢复。
- 伤害由服务端结算，使用生物自身的 `mobAttack` 伤害来源；不破坏方块、不制造爆炸。
- 不包含客户端动画模型；第一版依靠真实跳跃位移与落地粒子表现。
- 可通过 JSON 名单添加其他模组的近战 `Mob` 实体 ID。

## 默认参与生物

`minecraft:zombie`、`husk`、`drowned`、`zombie_villager`、`vindicator`、`piglin`、`piglin_brute`、`zombified_piglin`、`hoglin`、`zoglin`。

骷髅、流浪者、掠夺者、苦力怕、蜘蛛、首领生物默认不加入。远程生物不应直接加入名单，以免打乱其原有战斗逻辑。疣猪兽和猪灵等具体行为仍需在游戏中测试和调整。

## 配置

首次进入游戏后会生成：

`config/leapstrike.json`（技术配置文件名保持不变）

主要字段：

| 字段 | 默认值 | 含义 |
|---|---:|---|
| `enabled` | `true` | 总开关 |
| `minimumDistance` | `3.0` | 最小触发距离 |
| `maximumDistance` | `6.0` | 最大触发距离 |
| `windupTicks` | `10` | 蓄力 tick 数 |
| `cooldownTicks` | `160` | 冷却 tick 数 |
| `horizontalLeapVelocity` | `0.68` | 水平突进速度 |
| `verticalLeapVelocity` | `0.42` | 垂直起跳速度 |
| `slamRadius` | `2.3` | 落地范围半径 |
| `primaryDamageMultiplier` | `1.0` | 主目标伤害倍率（基于生物原攻击属性） |
| `splashDamageMultiplier` | `0.35` | 范围内其他玩家的伤害倍率 |
| `knockback` | `0.35` | 落地击退强度 |
| `supportedEntityIds` | 见默认名单 | 可发动跳劈的实体 ID |

修改配置后重启游戏生效。难度限制不可通过实体名单绕过：只有世界难度为困难（Hard）时才允许跳劈。要添加其他模组的近战生物，在 `supportedEntityIds` 数组中加入其实体注册 ID，例如 `"othermod:some_melee_mob"`。生物必须继承 Minecraft `Mob` 并使用原版目标系统将玩家设为目标，才可使用此通用 AI Goal。

## 构建

Minecraft 26.3 使用 Mojang 官方类名，不再配置 Yarn 映射。官方 Fabric 26.3 示例工程当前使用：

- Loom `1.19-SNAPSHOT`
- Gradle Wrapper `9.8.2`
- Java 25
- Fabric Loader `0.20.1`
- Fabric API `0.166.0+26.3`

本工程的构建文件已按上述工具链配置。将整个文件夹导入 Codespaces / IntelliJ IDEA，并在 Java 25 环境执行：

```bash
gradle build
```

成功后成品位于：

```text
build/libs/monster-rise-0.1.2+26.3.jar
```

如果终端没有 Gradle，请先安装 Gradle 9.8.2，再执行构建。不要用 Java 21 构建此版本。

## 当前验证状态

- 已核对 Fabric 26.3 的 Loom 插件 ID、依赖版本和 `ServerEntityEvents.ENTITY_LOAD` API。
- 已按 26.3 官方命名编写源码。
- **尚未完成 Gradle 编译与游戏内测试**：当前生成环境只有 Java 21，且无法解析外部 Maven / Gradle 下载域名，无法在此容器下载 Java 25 和构建依赖。因此此交付是源码工程，不是已经验证可运行的 JAR。
- 首次构建后应优先测试：僵尸、尸壳、溺尸、卫道士、猪灵、猪灵蛮兵、僵尸猪灵、疣猪兽；重点观察跳跃是否被原 AI 抢占、落地伤害是否恰好只结算一次、服务器端是否正常同步动作与击退。
