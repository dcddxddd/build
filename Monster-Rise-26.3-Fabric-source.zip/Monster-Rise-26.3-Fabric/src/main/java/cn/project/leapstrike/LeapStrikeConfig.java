package cn.project.leapstrike;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.world.entity.EntityType;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** File-based configuration; no mandatory Cloth Config/YACL dependency. */
public final class LeapStrikeConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("leapstrike.json");

    private static Settings current = defaults().toSettings();

    private LeapStrikeConfig() {
    }

    public static void load() {
        ConfigData data = defaults();
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            if (Files.exists(CONFIG_PATH)) {
                try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                    ConfigData loaded = GSON.fromJson(reader, ConfigData.class);
                    if (loaded != null) {
                        data = loaded;
                    }
                }
            }
            data.sanitize();
            current = data.toSettings();
            save(data);
        } catch (Exception exception) {
            LeapStrikeMod.LOGGER.error("Could not load LeapStrike config; using safe defaults.", exception);
            ConfigData safeDefaults = defaults();
            safeDefaults.sanitize();
            current = safeDefaults.toSettings();
            try {
                save(safeDefaults);
            } catch (Exception saveException) {
                LeapStrikeMod.LOGGER.error("Could not write default LeapStrike config.", saveException);
            }
        }
    }

    private static void save(ConfigData data) throws Exception {
        try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
            GSON.toJson(data, writer);
        }
    }

    public static Settings settings() {
        return current;
    }

    public static boolean isSupported(EntityType<?> type) {
        return current.enabled() && current.supportedEntityIds().contains(EntityType.getKey(type).toString());
    }

    private static ConfigData defaults() {
        ConfigData data = new ConfigData();
        data.supportedEntityIds = new ArrayList<>(List.of(
                "minecraft:zombie",
                "minecraft:husk",
                "minecraft:drowned",
                "minecraft:zombie_villager",
                "minecraft:vindicator",
                "minecraft:piglin",
                "minecraft:piglin_brute",
                "minecraft:zombified_piglin",
                "minecraft:hoglin",
                "minecraft:zoglin"
        ));
        return data;
    }

    public record Settings(
            boolean enabled,
            double minimumDistance,
            double maximumDistance,
            int windupTicks,
            int cooldownTicks,
            double horizontalLeapVelocity,
            double verticalLeapVelocity,
            double slamRadius,
            double primaryDamageMultiplier,
            double splashDamageMultiplier,
            double knockback,
            Set<String> supportedEntityIds
    ) {
    }

    private static final class ConfigData {
        private boolean enabled = true;
        private double minimumDistance = 3.0;
        private double maximumDistance = 6.0;
        private int windupTicks = 10;
        private int cooldownTicks = 160;
        private double horizontalLeapVelocity = 0.68;
        private double verticalLeapVelocity = 0.42;
        private double slamRadius = 2.3;
        private double primaryDamageMultiplier = 1.0;
        private double splashDamageMultiplier = 0.35;
        private double knockback = 0.35;
        private List<String> supportedEntityIds = new ArrayList<>();

        private void sanitize() {
            minimumDistance = clamp(minimumDistance, 1.0, 10.0);
            maximumDistance = clamp(maximumDistance, minimumDistance + 0.5, 14.0);
            windupTicks = clamp(windupTicks, 3, 40);
            cooldownTicks = clamp(cooldownTicks, 20, 1200);
            horizontalLeapVelocity = clamp(horizontalLeapVelocity, 0.15, 1.4);
            verticalLeapVelocity = clamp(verticalLeapVelocity, 0.15, 0.9);
            slamRadius = clamp(slamRadius, 0.5, 5.0);
            primaryDamageMultiplier = clamp(primaryDamageMultiplier, 0.1, 3.0);
            splashDamageMultiplier = clamp(splashDamageMultiplier, 0.0, 1.5);
            knockback = clamp(knockback, 0.0, 1.5);

            if (supportedEntityIds == null) {
                supportedEntityIds = new ArrayList<>();
            }
            Set<String> cleaned = new LinkedHashSet<>();
            for (String id : supportedEntityIds) {
                if (id != null && id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")) {
                    cleaned.add(id);
                }
            }
            supportedEntityIds = new ArrayList<>(cleaned);
        }

        private Settings toSettings() {
            return new Settings(
                    enabled,
                    minimumDistance,
                    maximumDistance,
                    windupTicks,
                    cooldownTicks,
                    horizontalLeapVelocity,
                    verticalLeapVelocity,
                    slamRadius,
                    primaryDamageMultiplier,
                    splashDamageMultiplier,
                    knockback,
                    Set.copyOf(supportedEntityIds)
            );
        }

        private static double clamp(double value, double min, double max) {
            if (Double.isNaN(value) || Double.isInfinite(value)) {
                return min;
            }
            return Math.max(min, Math.min(max, value));
        }

        private static int clamp(int value, int min, int max) {
            return Math.max(min, Math.min(max, value));
        }
    }
}
