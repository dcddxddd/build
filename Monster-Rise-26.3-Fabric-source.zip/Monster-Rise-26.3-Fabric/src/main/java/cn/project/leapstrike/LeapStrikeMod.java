package cn.project.leapstrike;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.world.entity.Mob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LeapStrike main entry point.
 *
 * Only mobs listed in config/leapstrike.json receive the additional AI goal.
 * No world-wide entity polling or attribute modification is performed.
 */
public final class LeapStrikeMod implements ModInitializer {
    public static final String MOD_ID = "leapstrike";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LeapStrikeConfig.load();

        ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
            if (!(entity instanceof Mob mob)) {
                return;
            }

            if (!LeapStrikeConfig.isSupported(mob.getType())) {
                return;
            }

            // Priority 1: takes MOVE/LOOK/JUMP controls only while the leap goal runs.
            mob.getGoalSelector().addGoal(1, new LeapStrikeGoal(mob));
        });

        LOGGER.info("LeapStrike loaded. Supported entity types: {}",
                LeapStrikeConfig.settings().supportedEntityIds().size());
    }
}
