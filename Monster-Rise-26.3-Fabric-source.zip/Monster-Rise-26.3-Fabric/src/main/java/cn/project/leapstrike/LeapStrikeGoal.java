package cn.project.leapstrike;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Server-side leap-strike state machine attached to an individual mob.
 * The default attack does not change the mob's base health, damage or speed.
 */
public final class LeapStrikeGoal extends Goal {
    private enum Phase {
        IDLE,
        WINDUP,
        LEAP
    }

    private final Mob mob;
    private Phase phase = Phase.IDLE;
    private Player attackTarget;
    private int windupRemaining;
    private int leapTicks;
    private long nextAttackGameTime;

    public LeapStrikeGoal(Mob mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK, Goal.Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        LeapStrikeConfig.Settings config = LeapStrikeConfig.settings();
        if (!config.enabled() || phase != Phase.IDLE || !mob.isAlive() || mob.isNoAi()) {
            return false;
        }
        // LeapStrike is intentionally active only in Hard difficulty.
        if (!isHardDifficulty() || mob.isPassenger() || mob.isInLiquid()) {
            return false;
        }
        if (mob.level().getGameTime() < nextAttackGameTime || !mob.onGround()) {
            return false;
        }

        if (!(mob.getTarget() instanceof Player player)) {
            return false;
        }
        return isValidWindupTarget(player, config);
    }

    @Override
    public boolean canContinueToUse() {
        return phase != Phase.IDLE && mob.isAlive() && isHardDifficulty();
    }

    @Override
    public void start() {
        if (!(mob.getTarget() instanceof Player player)) {
            cancel(20);
            return;
        }
        attackTarget = player;
        phase = Phase.WINDUP;
        windupRemaining = LeapStrikeConfig.settings().windupTicks();
        leapTicks = 0;
    }

    @Override
    public void stop() {
        if (phase != Phase.IDLE) {
            cancel(20);
        }
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        if (!(mob.level() instanceof ServerLevel level) || !isHardDifficulty()) {
            // Also abort an attack already charging or airborne if difficulty changes.
            cancel(20);
            return;
        }

        LeapStrikeConfig.Settings config = LeapStrikeConfig.settings();
        if (phase == Phase.WINDUP) {
            tickWindup(level, config);
        } else if (phase == Phase.LEAP) {
            tickLeap(level, config);
        }
    }

    private void tickWindup(ServerLevel level, LeapStrikeConfig.Settings config) {
        if (attackTarget == null || !isValidWindupTarget(attackTarget, config)
                || mob.distanceTo(attackTarget) > config.maximumDistance() + 3.0) {
            cancel(20);
            return;
        }

        mob.getNavigation().stop();
        mob.getLookControl().setLookAt(attackTarget, 35.0F, 35.0F);
        Vec3 velocity = mob.getDeltaMovement();
        mob.setDeltaMovement(velocity.x * 0.2, velocity.y, velocity.z * 0.2);

        if (windupRemaining % 3 == 0) {
            level.sendParticles(
                    ParticleTypes.CRIT,
                    mob.getX(), mob.getY() + mob.getBbHeight() * 0.75, mob.getZ(),
                    3, 0.22, 0.12, 0.22, 0.02
            );
        }

        windupRemaining--;
        if (windupRemaining <= 0) {
            beginLeap(config);
        }
    }

    private void beginLeap(LeapStrikeConfig.Settings config) {
        if (attackTarget == null || !attackTarget.isAlive()) {
            cancel(20);
            return;
        }

        mob.getNavigation().stop();
        Vec3 predictedTarget = attackTarget.position().add(attackTarget.getDeltaMovement().scale(3.0));
        Vec3 direction = predictedTarget.subtract(mob.position());
        Vec3 horizontal = new Vec3(direction.x, 0.0, direction.z);
        if (horizontal.lengthSqr() < 1.0E-5) {
            horizontal = new Vec3(0.0, 0.0, 1.0);
        } else {
            horizontal = horizontal.normalize();
        }

        float yaw = (float) (Math.toDegrees(Math.atan2(horizontal.z, horizontal.x)) - 90.0);
        mob.setYRot(yaw);
        mob.setDeltaMovement(
                horizontal.x * config.horizontalLeapVelocity(),
                config.verticalLeapVelocity(),
                horizontal.z * config.horizontalLeapVelocity()
        );

        phase = Phase.LEAP;
        leapTicks = 0;
    }

    private void tickLeap(ServerLevel level, LeapStrikeConfig.Settings config) {
        mob.getNavigation().stop();
        leapTicks++;

        // Ignore the pre-physics grounded state for the first few ticks.
        if ((leapTicks >= 4 && mob.onGround()) || leapTicks >= 32) {
            performSlam(level, config);
        }
    }

    private void performSlam(ServerLevel level, LeapStrikeConfig.Settings config) {
        double radius = config.slamRadius();
        AABB area = mob.getBoundingBox().inflate(radius, 1.25, radius);
        double baseDamage = Math.max(0.0, mob.getAttributeValue(Attributes.ATTACK_DAMAGE));

        for (Player victim : level.getEntitiesOfClass(Player.class, area, Player::isAlive)) {
            if (victim.isCreative() || victim.isSpectator() || !mob.canAttack(victim)) {
                continue;
            }

            if (victim.distanceToSqr(mob) > radius * radius) {
                continue;
            }
            if (!mob.getSensing().hasLineOfSight(victim)) {
                continue;
            }

            boolean primaryTarget = attackTarget != null && victim.getUUID().equals(attackTarget.getUUID());
            double multiplier = primaryTarget
                    ? config.primaryDamageMultiplier()
                    : config.splashDamageMultiplier();
            float damage = (float) (baseDamage * multiplier);
            if (damage <= 0.0F) {
                continue;
            }

            boolean hurt = victim.hurtServer(level, mob.damageSources().mobAttack(mob), damage);
            if (hurt && config.knockback() > 0.0) {
                Vec3 away = victim.position().subtract(mob.position());
                if (away.lengthSqr() < 1.0E-5) {
                    away = new Vec3(0.0, 0.0, 1.0);
                } else {
                    away = away.normalize();
                }
                victim.push(away.x * config.knockback(), 0.16, away.z * config.knockback());
            }
        }

        level.sendParticles(
                ParticleTypes.CLOUD,
                mob.getX(), mob.getY() + 0.08, mob.getZ(),
                14, radius * 0.14, 0.06, radius * 0.14, 0.025
        );
        level.sendParticles(
                ParticleTypes.CRIT,
                mob.getX(), mob.getY() + 0.18, mob.getZ(),
                7, radius * 0.12, 0.12, radius * 0.12, 0.04
        );

        nextAttackGameTime = level.getGameTime() + config.cooldownTicks();
        phase = Phase.IDLE;
        attackTarget = null;
    }

    private boolean isHardDifficulty() {
        return mob.level().getDifficulty() == Difficulty.HARD;
    }

    private boolean isValidWindupTarget(Player player, LeapStrikeConfig.Settings config) {
        if (!player.isAlive() || player.isCreative() || player.isSpectator()
                || player.level() != mob.level() || mob.getTarget() != player || !mob.canAttack(player)) {
            return false;
        }

        double distance = mob.distanceTo(player);
        return distance >= config.minimumDistance()
                && distance <= config.maximumDistance()
                && mob.getSensing().hasLineOfSight(player);
    }

    private void cancel(int retryDelay) {
        phase = Phase.IDLE;
        attackTarget = null;
        windupRemaining = 0;
        leapTicks = 0;
        nextAttackGameTime = mob.level().getGameTime() + retryDelay;
    }
}
