# Codespaces 构建步骤

1. 上传或将此文件夹放入 Codespaces 工作区。
2. 确认 `java -version` 显示 Java 25。
3. 确认 `gradle --version` 为 Gradle 9.8.2。
4. 在项目根目录运行 `gradle build`。
5. 取出 `build/libs/monster-rise-0.1.2+26.3.jar`。

若 Gradle 下载 Loom、Minecraft 或 Fabric API 时遇到 DNS/网络错误，先确保 Codespaces 能访问 `maven.fabricmc.net`、`services.gradle.org` 与 Maven Central，再重新运行构建。
