# 下一阶段状态（r1.4.4）

## 已落地
1. 自定义箱子加入 vanilla `ChestType` 对应的 `chest_type` 状态。
2. 服务端按同类型、同朝向、侧向相邻的配对结果同步 `LEFT/RIGHT`，无配对时回到 `SINGLE`。
3. 所有 11 种箱子 blockstate 资源均覆盖 192 种状态组合。

## 下一步
1. 将整箱静态 JSON 模型拆为 SINGLE、LEFT、RIGHT 三套几何，明确接缝面隐藏和边缘框架连续性。
2. 每个开盖阶段分别生成左右半模型，避免箱盖穿插和双重厚度。
3. 为每种材质提供左右半箱独立 UV/纹理布局；铜箱保留氧化层级。
4. 核实 26.3 原版 ChestSpecialRenderer / ChestModel 的模型资源路径，评估用原版特殊模型渲染体系实现同步开盖动画，而不是套用旧版 BER API。
5. 用 Java 25、Gradle wrapper 构建，并在 26.3 Fabric 客户端/服务端验证单箱、左右双箱、拆箱、旋转朝向和开盖动画。
