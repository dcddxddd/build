#!/usr/bin/env python3
"""Static validator for More Chests r1.4.9 (resources + source invariants only)."""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'src/main/resources'
ASSETS = RES / 'assets/moreexpandedchests'
DATA = RES / 'data/moreexpandedchests'
JAVA = ROOT / 'src/main/java/dev/moreexpandedchests'
CLIENT = ROOT / 'src/client/java/dev/moreexpandedchests/client'
CAPACITIES = {
    'copper_chest':54, 'iron_chest':81, 'gold_chest':108, 'diamond_chest':135,
    'netherite_chest':189, 'glass_chest':54, 'lapis_chest':27, 'coal_chest':18,
    'charcoal_chest':18, 'emerald_chest':27, 'echo_chest':2700, 'amethyst_chest':4,
}
errors=[]; checks=[]
def require(ok, msg):
    (checks if ok else errors).append(('PASS ' if ok else 'FAIL ') + msg)
def loadj(path):
    try: return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'FAIL JSON parse {path.relative_to(ROOT)}: {exc}')
        return {}

# JSON parse and project metadata.
json_files=list(RES.rglob('*.json'))
for p in json_files: loadj(p)
require(True, f'JSON parse pass ({len(json_files)} files)')
metadata=loadj(RES/'fabric.mod.json')
require(metadata.get('id')=='moreexpandedchests', 'mod id remains moreexpandedchests')
require(metadata.get('version')=='${version}', 'Fabric version is expanded from Gradle project.version')
require(metadata.get('depends',{}).get('minecraft')=='26.3', 'Minecraft target is 26.3')
require(metadata.get('depends',{}).get('java')=='>=25', 'Java target is 25+')
props=(ROOT/'gradle.properties').read_text()
require('mod_version=1.4.9' in props, 'Gradle version is 1.4.9')

# Registry capacities / charcoal split.
main=(JAVA/'MoreExpandedChests.java').read_text()
registered={k:int(v) for k,v in re.findall(r'registerChest\("([a-z_]+)",\s*(\d+)',main)}
require(registered==CAPACITIES, f'12 chest capacities match design ({registered})')
require('CHARCOAL_CHEST' in main and 'charcoal_chest' in main, 'Charcoal Chest registered separately')
require('charcoal_chest_upgrade_template' in main, 'Charcoal upgrade template registered')
require('new CookingFuel(new ResolvableInt.Constant(128000)' in main and 'name.equals("charcoal_chest")' in main,
        'Coal and Charcoal Chest both carry 128000-tick CookingFuel components')
require('itemProperties.fireResistant();' in main, 'all registered chest items are fire resistant')
require('import net.fabricmc.fabric.api.registry.FlammableBlockRegistry' not in main and 'FlammableBlockRegistry.getDefaultInstance().add' not in main, 'no chest block is registered as flammable')
require('CHARCOAL_CHEST' in main.split('FabricBlockEntityTypeBuilder.create',1)[1].split(').build()',1)[0],
        'Charcoal Chest BlockEntity type registered')

# Blockstates and models.
blockstates=ASSETS/'blockstates'
model_refs=0; missing_models=[]
for chest in CAPACITIES:
    state=loadj(blockstates/f'{chest}.json')
    expected=192 if chest=='copper_chest' else 48
    require(len(state.get('variants',{}))==expected, f'{chest} BlockState has {expected} facing/open/type variants')
    for variant, entries in state.get('variants',{}).items():
        entries=entries if isinstance(entries,list) else [entries]
        for entry in entries:
            if not isinstance(entry,dict): continue
            model=entry.get('model')
            if not model: continue
            ns, path=model.split(':',1) if ':' in model else ('minecraft',model)
            if ns=='moreexpandedchests':
                model_refs+=1
                if not (ASSETS/'models'/f'{path}.json').exists(): missing_models.append(f'{chest}:{variant}->{path}')
    require((ASSETS/f'models/block/{chest}.json').exists(), f'{chest} base model exists')
    require((ASSETS/f'models/item/{chest}.json').exists(), f'{chest} item model exists')
    require((ASSETS/f'items/{chest}.json').exists(), f'{chest} item definition exists')
    require((DATA/f'loot_table/blocks/{chest}.json').exists(), f'{chest} block loot table exists')
require(not missing_models, f'all {model_refs} BlockState model refs resolve')

# Model texture refs and UV coverage.
texture_refs=0; missing_textures=[]; uv_faces=0; bad_uv=[]
for p in (ASSETS/'models').rglob('*.json'):
    model=loadj(p)
    for value in model.get('textures',{}).values():
        if not isinstance(value,str) or value.startswith('#') or ':' not in value: continue
        ns, tid=value.split(':',1)
        if ns=='moreexpandedchests':
            texture_refs+=1
            if not (ASSETS/'textures'/f'{tid}.png').exists(): missing_textures.append(f'{p.relative_to(ROOT)}->{value}')
    for element in model.get('elements',[]):
        for face in element.get('faces',{}).values():
            uv=face.get('uv')
            if uv:
                uv_faces+=1
                if len(uv)!=4 or min(uv)<0 or max(uv)>32: bad_uv.append(f'{p.relative_to(ROOT)}:{uv}')
require(not missing_textures, f'all {texture_refs} model texture refs resolve')
require(not bad_uv, f'all {uv_faces} model UVs fit the 32x32 texture sheets')

# All 76 face texture files must be 32x32 RGBA; charcoal set added.
block_png=list((ASSETS/'textures/block').glob('*.png'))
invalid=[]
for p in block_png:
    try:
        with Image.open(p) as im:
            if im.size!=(32,32) or im.mode!='RGBA': invalid.append((p.name,im.size,im.mode))
    except Exception as exc: invalid.append((p.name,str(exc)))
require(not invalid, f'block texture PNGs are 32x32 RGBA ({len(block_png)} files)')
require(all((ASSETS/f'textures/block/charcoal_chest_{face}.png').exists() for face in ('front','side','top','bottom')),
        'Charcoal Chest has independent front/side/top/bottom textures')

# Charcoal recipes and common chest tags.
for f in ('charcoal_chest.json','charcoal_chest_upgrade_template.json'):
    rec=loadj(DATA/f'recipe/{f}')
    require(rec.get('type')=='minecraft:crafting_shaped', f'{f} parses as shaped recipe')
    require('minecraft:charcoal' in json.dumps(rec), f'{f} uses charcoal material')
for rel in ('data/c/tags/block/chests.json','data/c/tags/item/chests.json'):
    tag=loadj(RES/rel)
    require('moreexpandedchests:charcoal_chest' in tag.get('values',[]), f'{rel} includes charcoal chest')

# Tool tags and harvest-level assignments.
axe=loadj(RES/'data/minecraft/tags/block/mineable/axe.json').get('values',[])
pick=loadj(RES/'data/minecraft/tags/block/mineable/pickaxe.json').get('values',[])
stone=loadj(RES/'data/minecraft/tags/block/needs_stone_tool.json').get('values',[])
iron=loadj(RES/'data/minecraft/tags/block/needs_iron_tool.json').get('values',[])
diamond=loadj(RES/'data/minecraft/tags/block/needs_diamond_tool.json').get('values',[])
require({'minecraft:chest','minecraft:trapped_chest','minecraft:barrel'}.issubset(set(axe)), 'vanilla wood chest/trapped chest/barrel use axe tag')
require(set(f'moreexpandedchests:{n}' for n in CAPACITIES).issubset(set(pick)), 'all twelve mod chests use pickaxe tag')
require('moreexpandedchests:charcoal_chest' in stone, 'Charcoal Chest has stone-pickaxe level')
require('moreexpandedchests:echo_chest' in diamond, 'Echo Chest remains pickaxe-tier gated before Netherite check')

# Gameplay source invariants.
block=(JAVA/'TieredChestBlock.java').read_text()
be=(JAVA/'TieredChestBlockEntity.java').read_text()
removal=(JAVA/'mixin/EchoChestEntityRemovalMixin.java').read_text()
damage=(JAVA/'mixin/EchoChestItemDamageMixin.java').read_text()
menu=(JAVA/'TieredChestMenu.java').read_text()
screen=(CLIENT/'TieredChestScreen.java').read_text()
payload=(JAVA/'network/ChestPagePayload.java').read_text()
require('getBlockState().getBlock() == MoreExpandedChests.COAL_CHEST' in be and 'stack.getItem() != Items.COAL' in be,
        'Coal Chest has a coal-only insertion rule')
require('MoreExpandedChests.CHARCOAL_CHEST' in be and 'Items.CHARCOAL' in be,
        'Charcoal Chest has a charcoal-only insertion rule')
require('Items.NETHERITE_PICKAXE' in block and 'LootContextParams.TOOL' in block,
        'Echo Chest drop requires exact Netherite Pickaxe')
require('MoreExpandedChests.isChestItem' in damage and 'fireImmune' in damage and 'hurtServer' in damage,
        'all chest item entities are protected from fire/cactus damage')
require('checkBelowWorld' in removal and 'getMinY() - 30.0D' in removal,
        'Echo Chest item is recovered at 30 blocks below minY')
require('method = "remove' not in removal and 'RemovalReason' not in removal,
        'Echo Chest mixin does not intercept deliberate discard/remove/creative clear')
require('rowsFor(blockEntity.getContainerSize())' in menu and 'menuChestSlotCount' in menu
        and 'public boolean canPlaceItem(int slot, ItemStack stack)' in menu
        and 'pagedContainer.setOffset(scrollRow * COLUMNS)' in menu,
        'Chest menu rows, slot bounds and client page offsets are capacity-aware')
require('generic_54.png' in screen and '176' in screen and 'frameTexture' not in screen
        and 'leftPos += 16' not in screen and 'topPos += 6' not in screen
        and '0.0F, 126.0F, 176, 96' in screen and 'super.extractBackground' in screen,
        'GUI uses vanilla-width panel, split background and no expanded material frame')
require('CONTROL_STRIP_HEIGHT' in screen and '20, 20' in screen,
        'GUI has isolated lower control strip and same 20x20 controls')
require('AMETHYST_CHEST' in screen and '4 * 18' in screen,
        'Amethyst GUI masks unused slots and presents four active positions')
require('int maxRow = (pageCount - 1) * 6' in payload,
        'network paging validates six-row page boundaries')

# Mod source class and resource wiring count checks.
require('CHARCOAL_CHEST' in (JAVA/'MoreExpandedChests.java').read_text() and 'block != MoreExpandedChests.CHARCOAL_CHEST' not in be, 'Charcoal chest inventory uses the shared block-removal drop path')
require('block != MoreExpandedChests.COAL_CHEST' not in be and 'block != MoreExpandedChests.CHARCOAL_CHEST' not in be, 'Coal and Charcoal inventory use the generic removal drop path')

report=ROOT/'STATIC_VALIDATION_r1.4.9.txt'
report.write_text('\n'.join(checks+errors)+f'\n\nChecks passed: {len(checks)}\nErrors: {len(errors)}\n',encoding='utf-8')
print(report.read_text())
if errors: sys.exit(1)
