# 26.3 双箱渲染接入记录（r1.4.5）

## 已核实的原版接口

- `net.minecraft.world.level.block.entity.LidBlockEntity` 提供 `getOpenNess(float)`。
- 26.3 的 `ChestRenderer` 使用 `ChestRenderState`、`extractRenderState` 与 `submit` 新式渲染流程。
- `ChestSpecialRenderer.Unbaked` 已包含 `texture`、`openness`、`chest_type` 字段；原版胸箱资源使用 `MultiblockChestResources` 区分单箱、左半箱和右半箱纹理。
- Fabric 26.2+ 文档示例采用 `BlockEntityRenderers.register`，而不是旧版 `BlockEntityRendererRegistry` 工厂 API。

## 本版实际改动

`TieredChestBlockEntity` 实现 `LidBlockEntity`，`getOpenNess(float)` 将现有 `OPEN_STAGE`（0 至 3）归一化为 0.0 至 1.0。该方法只读取方块状态，不引用客户端类，可留在 common source set。

## 下一步实现顺序

1. 从 26.3 `ChestRenderer` 源码核对可覆写入口、纹理 atlas 的 `SpriteId` 构造方法，以及 `ChestRenderState` 的 `ChestType` / 朝向字段。
2. 为 11 种材质生成符合原版 chest atlas UV 布局的纹理资源，分别提供 single / left / right；铜箱还要覆盖四种氧化阶段。
3. 为 `TieredChestBlockEntity` 注册统一 renderer，并按方块材质、氧化阶段、`CHEST_TYPE` 选择纹理资源。
4. 双箱只提交一套正确的半箱模型布局；检查左右半边、缝隙、墙面遮挡、朝向、开盖同步和资源重载。
5. 通过 Java 25 + Gradle 9.9 构建，并在 Minecraft 26.3 Fabric 客户端实测。

## 明确限制

当前已有的 `front / side / top / bottom` 方块贴图不是原版 chest atlas。直接把它们作为 `ChestRenderer` sprite 会造成 UV 错位；不能只复制文件并命名 `_left` / `_right` 来假称适配完成。
