# r1.2.5

- Fixed the fatal Minecraft 26.3 recipe-registry parse failure for `moreexpandedchests:chest_upgrade_template`.
- Updated smithing transform `template` and `base` ingredients from legacy `{ "item": "..." }` objects to 26.3 item-ID strings.
- Added a regression guard to the static validator for all recipe ingredient fields.
- Preserved the intended smithing-table recipe: vanilla chest + netherite upgrade smithing template, with no extra addition item.

Build and in-game verification remain separate; this package has not been compiled or run in Minecraft in the current environment.
