# 来源日志诊断 — More Expanded Chests r1.2.8

## 日志中的直接崩溃

用户上传的 `latest_game(6).log` 实际加载 `moreexpandedchests 1.2.5-26.3`。服务端在 `TieredChestBlockEntity.getUpdateTag` 序列化玻璃箱展示物品时，尝试将 `ItemStack.EMPTY` 编码为 `minecraft:air` 且 count 0。26.3 ItemStack Codec 要求有效物品栈，因此触发：

```text
IllegalStateException: Value must be within range [1;99]: 0; Item must not be minecraft:air
```

这属于服务端区块同步中的玻璃箱预览栈序列化错误，不是该日志显示出的 `GlassChestRenderer` 直接异常。

## r1.2.8 修复

- 空预览时不写入 `glassDisplayStack` 更新标签。
- 非空物品预览使用 `ItemStack.CODEC.encodeStart(NbtOps.INSTANCE, stack).result()`；编码失败只省略预览字段，不让区块同步崩溃。
- 预览扫描逻辑容器，包括相邻配对玻璃箱的两半库存。

## 其他来源说明

用户上传的画面截图是世界场景 HUD 与移动端触控层，没有显示箱子 GUI。不能根据该图判断排序按钮或边框的实际游戏内位置。

## 其他日志问题

同一日志里出现的 Vulkan/渲染后端、Better Clouds 与 Iris 的 Mixin 兼容问题属于独立问题；不能据此归因到 More Expanded Chests 的箱子代码。
