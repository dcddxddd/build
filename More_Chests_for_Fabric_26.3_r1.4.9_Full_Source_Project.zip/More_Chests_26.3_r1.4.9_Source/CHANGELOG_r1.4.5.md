# More Chests r1.4.5

## Vanilla chest-renderer compatibility groundwork
- `TieredChestBlockEntity` now implements Minecraft 26.3's `LidBlockEntity` contract.
- Added `getOpenNess(float)` backed by the existing synchronized `OPEN_STAGE` block state, normalized to `[0, 1]`.
- This exposes lid openness to a future vanilla-compatible chest block-entity renderer without introducing client-only classes into the common source set.
- Preserved `CHEST_TYPE` (`SINGLE`/`LEFT`/`RIGHT`), paired inventory logic, GUI resources, mod id, and registry namespace.

## Not included yet
- No generic `ChestRenderer` has been registered for the 11 chest tiers.
- The existing block models still render the visible chest geometry; all chest type variants currently point to the same full model.
- Chest atlas textures for single/left/right are not yet generated. Existing block face textures are not interchangeable with the vanilla chest atlas format.
- Double-chest geometry, lid interpolation, and in-game behavior remain unverified.

## Validation
- Static project validation and resource JSON checks are run for this source snapshot.
- Java 25 / Gradle compilation and Minecraft 26.3 in-game tests have not been run in this environment.
