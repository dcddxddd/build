package dev.moreexpandedchests.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.moreexpandedchests.TieredChestBlock;
import dev.moreexpandedchests.TieredChestBlockEntity;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public final class GlassChestRenderer implements BlockEntityRenderer<TieredChestBlockEntity, GlassChestRenderState> {
    private final ItemModelResolver itemModelResolver;

    public GlassChestRenderer(BlockEntityRendererProvider.Context context) {
        this.itemModelResolver = context.itemModelResolver();
    }

    @Override
    public GlassChestRenderState createRenderState() {
        return new GlassChestRenderState();
    }

    @Override
    public void extractRenderState(
            TieredChestBlockEntity blockEntity,
            GlassChestRenderState state,
            float partialTicks,
            Vec3 cameraPosition,
            ModelFeatureRenderer.CrumblingOverlay breakProgress
    ) {
        BlockEntityRenderer.super.extractRenderState(blockEntity, state, partialTicks, cameraPosition, breakProgress);
        ItemStack displayed = blockEntity.getGlassDisplayStack();
        if (displayed.isEmpty()) {
            // Render states are reused; clear the previous carousel item explicitly.
            state.displayedItem.clear();
        } else {
            itemModelResolver.updateForTopItem(
                    state.displayedItem,
                    displayed,
                    ItemDisplayContext.FIXED,
                    blockEntity.getLevel(),
                    null,
                    blockEntity.getBlockPos().hashCode() + blockEntity.glassDisplayIndex()
            );
        }
        state.facing = blockEntity.getBlockState().getValue(TieredChestBlock.FACING);
    }

    @Override
    public void submit(
            GlassChestRenderState state,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CameraRenderState camera
    ) {
        if (state.displayedItem.isEmpty()) return;

        double x = 0.5D;
        double z = 0.5D;
        float rotation;
        switch (state.facing) {
            case NORTH -> { z = 0.045D; rotation = 0.0F; }
            case SOUTH -> { z = 0.955D; rotation = 180.0F; }
            case EAST -> { x = 0.955D; rotation = -90.0F; }
            case WEST -> { x = 0.045D; rotation = 90.0F; }
            default -> { rotation = 0.0F; }
        }

        poseStack.pushPose();
        poseStack.translate(x, 0.55D, z);
        poseStack.mulPose(new org.joml.Matrix4f().rotation(Axis.YP.rotationDegrees(rotation)));
        poseStack.scale(0.24F, 0.24F, 0.24F);
        state.displayedItem.submit(poseStack, collector, 15728880, 0, 0);
        poseStack.popPose();
    }
}
