package dev.moreexpandedchests.client;

import dev.moreexpandedchests.MoreExpandedChests;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;

public final class MoreExpandedChestsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MenuScreens.register(MoreExpandedChests.CHEST_MENU, TieredChestScreen::new);
        BlockEntityRenderers.register(MoreExpandedChests.CHEST_BLOCK_ENTITY, GlassChestRenderer::new);
    }
}
