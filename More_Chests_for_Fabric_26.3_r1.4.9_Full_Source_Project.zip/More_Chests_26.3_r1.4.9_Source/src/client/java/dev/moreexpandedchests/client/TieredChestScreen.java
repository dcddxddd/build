package dev.moreexpandedchests.client;

import dev.moreexpandedchests.MoreExpandedChests;
import dev.moreexpandedchests.TieredChestMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;

/** Vanilla chest panel with compact capacity rows and an isolated control strip. */
public final class TieredChestScreen extends AbstractContainerScreen<TieredChestMenu> {
    private static final Identifier VANILLA_CHEST = Identifier.withDefaultNamespace(
            "textures/gui/container/generic_54.png");
    private static final int CONTROL_STRIP_HEIGHT = 24;
    private final int vanillaPanelHeight;

    public TieredChestScreen(TieredChestMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title, 176,
                114 + menu.getVisibleRows() * 18 + CONTROL_STRIP_HEIGHT);
        this.vanillaPanelHeight = 114 + menu.getVisibleRows() * 18;
    }

    @Override
    protected void init() {
        inventoryLabelY = vanillaPanelHeight - 94;
        titleLabelX = 27;
        super.init();

        // One common button size for the upper-left action and both lower page controls.
        addRenderableWidget(Button.builder(Component.literal("≡"), button -> {
            Minecraft client = minecraft;
            if (client != null && client.gameMode != null) {
                client.gameMode.handleInventoryButtonClick(menu.containerId, TieredChestMenu.SORT_ALL_BUTTON_ID);
            }
        }).bounds(leftPos + 4, topPos + 3, 20, 20)
                .tooltip(Tooltip.create(Component.translatable("gui.moreexpandedchests.sort.tooltip")))
                .build());

        addRenderableWidget(Button.builder(Component.literal("‹"), button -> {
            requestScroll(menu.getPreviousPageRow());
        }).bounds(leftPos + 42, topPos + vanillaPanelHeight + 2, 20, 20)
                .tooltip(Tooltip.create(Component.translatable("gui.moreexpandedchests.page.previous")))
                .build());

        addRenderableWidget(Button.builder(Component.literal("›"), button -> {
            requestScroll(menu.getNextPageRow());
        }).bounds(leftPos + 114, topPos + vanillaPanelHeight + 2, 20, 20)
                .tooltip(Tooltip.create(Component.translatable("gui.moreexpandedchests.page.next")))
                .build());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(graphics, mouseX, mouseY, partialTick);
        // Match vanilla ContainerScreen's split generic_54 drawing: render the chest grid
        // from texture row 0, then move the fixed 96px player-inventory section directly
        // below the actual number of chest rows. A single full-height blit misaligns the
        // player inventory art whenever this menu has fewer than six rows.
        int chestGridHeight = menu.getVisibleRows() * 18 + 17;
        graphics.blit(RenderPipelines.GUI_TEXTURED, VANILLA_CHEST, leftPos, topPos,
                0.0F, 0.0F, 176, chestGridHeight, 256, 256);
        graphics.blit(RenderPipelines.GUI_TEXTURED, VANILLA_CHEST, leftPos, topPos + chestGridHeight,
                0.0F, 126.0F, 176, 96, 256, 256);

        // The 24px control strip is below the entire vanilla panel and does not cover player slots.
        graphics.fill(leftPos, topPos + vanillaPanelHeight, leftPos + 176,
                topPos + vanillaPanelHeight + CONTROL_STRIP_HEIGHT, 0xFF303030);

        // The Amethyst Chest has exactly four storage slots. Mask the five unused vanilla
        // cells in its single row so its UI presents four slots rather than nine.
        if (menu.getChestBlock() == MoreExpandedChests.AMETHYST_CHEST) {
            graphics.fill(leftPos + 8 + 4 * 18, topPos + 18,
                    leftPos + 8 + 9 * 18, topPos + 36, 0xFFC6C6C6);
        }

        graphics.drawCenteredString(Minecraft.getInstance().font,
                Component.translatable("gui.moreexpandedchests.page.counter", menu.getCurrentPage(), menu.getPageCount()),
                leftPos + 88, topPos + vanillaPanelHeight + 8, 0xFFFFFFFF);
    }

    private boolean isOverStorageGrid(double mouseX, double mouseY) {
        int right = menu.getChestBlock() == MoreExpandedChests.AMETHYST_CHEST
                ? leftPos + 8 + 4 * 18 : leftPos + 168;
        return mouseX >= leftPos + 8 && mouseX < right
                && mouseY >= topPos + 18 && mouseY < topPos + 18 + menu.getVisibleRows() * 18;
    }

    private void requestScroll(int requestedRow) {
        int target = Math.max(0, Math.min(menu.getMaxScrollRows(), requestedRow));
        if (target == menu.getScrollRow()) return;
        menu.setScrollRow(target);
        Minecraft client = minecraft;
        if (client != null && client.gameMode != null) {
            client.gameMode.handleInventoryButtonClick(menu.containerId, target);
        }
    }

    /** Mouse-wheel input only pages the storage grid; the player inventory is unaffected. */
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (isOverStorageGrid(mouseX, mouseY) && menu.getMaxScrollRows() > 0 && verticalAmount != 0.0D) {
            requestScroll(menu.getScrollRow() + (verticalAmount > 0.0D ? -1 : 1));
            return true;
        }
        return false;
    }
}
