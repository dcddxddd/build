package dev.moreexpandedchests.client;
import dev.moreexpandedchests.TieredChestMenu;
import dev.moreexpandedchests.network.ChestPagePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
public final class PageSyncClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ChestPagePayload.ID, (payload, context) -> {
            if (context.player().containerMenu instanceof TieredChestMenu menu) menu.applyPageSnapshot(payload);
        });
    }
}
