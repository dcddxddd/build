package dev.moreexpandedchests.client;

import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.core.Direction;

public final class GlassChestRenderState extends BlockEntityRenderState {
    public final ItemStackRenderState displayedItem = new ItemStackRenderState();
    public Direction facing = Direction.SOUTH;
}
