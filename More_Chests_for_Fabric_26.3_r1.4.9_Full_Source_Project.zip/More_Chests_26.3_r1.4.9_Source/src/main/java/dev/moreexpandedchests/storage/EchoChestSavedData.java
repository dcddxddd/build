package dev.moreexpandedchests.storage;

import com.mojang.serialization.Codec;
import dev.moreexpandedchests.MoreExpandedChests;
import net.minecraft.core.NonNullList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * World-global Echo Chest inventory. Storing it in server SavedData makes it shared
 * between dimensions and keeps the contents when the physical chest block is moved.
 */
public final class EchoChestSavedData extends SavedData {
    public static final int SLOT_COUNT = 2700;
    private static final int PAGE_SIZE = ItemContainerContents.MAX_SIZE;

    private static final Codec<EchoChestSavedData> CODEC = ItemContainerContents.CODEC.listOf()
            .xmap(EchoChestSavedData::new, EchoChestSavedData::toPages);

    private static final SavedDataType<EchoChestSavedData> TYPE = new SavedDataType<>(
            MoreExpandedChests.id("echo_chest_storage"),
            EchoChestSavedData::new,
            CODEC,
            null
    );

    private final SimpleContainer inventory = new SimpleContainer(SLOT_COUNT);

    public EchoChestSavedData() {
    }

    private EchoChestSavedData(List<ItemContainerContents> pages) {
        for (int pageIndex = 0; pageIndex < pages.size(); pageIndex++) {
            ItemContainerContents page = pages.get(pageIndex);
            int firstSlot = pageIndex * PAGE_SIZE;
            if (firstSlot >= SLOT_COUNT) break;
            // In 26.3 nonEmptyItems() is an Iterable<ItemStackTemplate>, not a sized
            // collection of ItemStacks. Materialize templates before allocating the page.
            List<ItemStack> materialized = new ArrayList<>();
            for (ItemStackTemplate template : page.nonEmptyItems()) {
                materialized.add(template.create());
            }
            NonNullList<ItemStack> restored = NonNullList.withSize(Math.max(1, materialized.size()), ItemStack.EMPTY);
            for (int slot = 0; slot < materialized.size(); slot++) {
                restored.set(slot, materialized.get(slot));
            }
            page.copyInto(restored);
            for (int slot = 0; slot < restored.size() && firstSlot + slot < SLOT_COUNT; slot++) {
                inventory.setItem(firstSlot + slot, restored.get(slot));
            }
        }
    }

    public static EchoChestSavedData get(MinecraftServer server) {
        return server.getDataStorage().computeIfAbsent(TYPE);
    }

    public SimpleContainer inventory() {
        return inventory;
    }

    private List<ItemContainerContents> toPages() {
        List<ItemContainerContents> pages = new ArrayList<>();
        List<ItemStack> allItems = inventory.getItems();
        for (int firstSlot = 0; firstSlot < SLOT_COUNT; firstSlot += PAGE_SIZE) {
            int end = Math.min(firstSlot + PAGE_SIZE, SLOT_COUNT);
            pages.add(ItemContainerContents.fromItems(new ArrayList<>(allItems.subList(firstSlot, end))));
        }
        return pages;
    }

    public void markDirty() {
        setDirty();
    }
}
