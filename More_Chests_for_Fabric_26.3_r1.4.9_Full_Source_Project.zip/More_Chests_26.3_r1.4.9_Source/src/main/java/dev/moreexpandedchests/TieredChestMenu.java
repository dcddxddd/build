package dev.moreexpandedchests;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.core.registries.BuiltInRegistries;
import dev.moreexpandedchests.network.ChestPagePayload;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.IdentityHashMap;

public final class TieredChestMenu extends ChestMenu {
    public static final int COLUMNS = 9;
    public static final int VISIBLE_ROWS = 6; // Maximum page height; vanilla chest rows are 9 slots each.
    public static final int VISIBLE_STORAGE_SLOTS = COLUMNS * VISIBLE_ROWS;
    public static final int SORT_ALL_BUTTON_ID = 1000;

    private final TieredChestBlockEntity blockEntity;
    private final PagedContainer pagedContainer;
    private final Player viewer;
    private final int visibleRows;
    private final int menuChestSlotCount;
    private int scrollRow;
    private int knownStorageSize;
    private int pageRevision;
    private int lastAppliedRevision = -1;

    public TieredChestMenu(int containerId, Inventory playerInventory, BlockPos position) {
        this(containerId, playerInventory, findBlockEntity(playerInventory, position));
    }

    private static TieredChestBlockEntity findBlockEntity(Inventory inventory, BlockPos position) {
        if (inventory.player.level().getBlockEntity(position) instanceof TieredChestBlockEntity chest) return chest;
        throw new IllegalStateException("Missing More Expanded Chests block entity at " + position);
    }

    public TieredChestMenu(int containerId, Inventory inventory, TieredChestBlockEntity blockEntity) {
        this(containerId, inventory, blockEntity, new PagedContainer(blockEntity, inventory.player.level().isClientSide()));
    }

    private TieredChestMenu(int containerId, Inventory inventory, TieredChestBlockEntity blockEntity, PagedContainer paged) {
        super(MoreExpandedChests.CHEST_MENU, containerId, inventory, paged, rowsFor(blockEntity.getContainerSize()));
        this.blockEntity = blockEntity;
        this.pagedContainer = paged;
        this.viewer = inventory.player;
        this.visibleRows = rowsFor(blockEntity.getContainerSize());
        this.menuChestSlotCount = visibleRows * COLUMNS;
        this.knownStorageSize = blockEntity.getContainerSize();
        this.blockEntity.startOpen(inventory.player);
    }

    private static int rowsFor(int size) {
        return Math.max(1, Math.min(VISIBLE_ROWS, (Math.max(1, size) + COLUMNS - 1) / COLUMNS));
    }

    public int getVisibleRows() { return visibleRows; }
    public int getScrollRow() { return scrollRow; }
    public int getCurrentPage() { return Math.min(getPageCount(), scrollRow / VISIBLE_ROWS + 1); }
    public int getPageCount() {
        int size = pagedContainer.isClientPage() ? knownStorageSize : blockEntity.getContainerSize();
        int rows = (size + COLUMNS - 1) / COLUMNS;
        return Math.max(1, (rows + VISIBLE_ROWS - 1) / VISIBLE_ROWS);
    }
    public TieredChestBlock getChestBlock() {
        return (TieredChestBlock) blockEntity.getBlockState().getBlock();
    }
    public int getMaxScrollRows() {
        int size = pagedContainer.isClientPage() ? knownStorageSize : blockEntity.getContainerSize();
        int totalRows = (size + COLUMNS - 1) / COLUMNS;
        int pageCount = Math.max(1, (totalRows + VISIBLE_ROWS - 1) / VISIBLE_ROWS);
        // Start each page on a six-row boundary; the final page may contain fewer rows.
        return (pageCount - 1) * VISIBLE_ROWS;
    }

    public int getPreviousPageRow() {
        if (scrollRow == getMaxScrollRows() && scrollRow > 0 && scrollRow % VISIBLE_ROWS != 0) {
            return Math.max(0, ((scrollRow - 1) / VISIBLE_ROWS) * VISIBLE_ROWS);
        }
        return Math.max(0, scrollRow - VISIBLE_ROWS);
    }

    public int getNextPageRow() {
        return Math.min(getMaxScrollRows(), scrollRow + VISIBLE_ROWS);
    }

    public void setScrollRow(int requested) {
        int clamped = Math.max(0, Math.min(getMaxScrollRows(), requested));
        if (clamped == scrollRow) return;
        scrollRow = clamped;
        pagedContainer.setOffset(scrollRow * COLUMNS);
    }

    public void applyPageSnapshot(ChestPagePayload payload) {
        if (!pagedContainer.isClientPage() || payload.containerId() != containerId || payload.revision() <= lastAppliedRevision) return;
        knownStorageSize = payload.totalSlots();
        scrollRow = Math.max(0, Math.min(getMaxScrollRows(), payload.scrollRow()));
        pagedContainer.setOffset(scrollRow * COLUMNS);
        pagedContainer.applyClientPage(payload.stacks());
        lastAppliedRevision = payload.revision();
    }

    @Override
    public void broadcastFullState() {
        super.broadcastFullState();
        sendAuthoritativePage();
    }

    private void sendAuthoritativePage() {
        if (!(viewer instanceof net.minecraft.server.level.ServerPlayer serverPlayer) || viewer.level().isClientSide()) return;
        List<ItemStack> page = new ArrayList<>(VISIBLE_STORAGE_SLOTS);
        int first = scrollRow * COLUMNS;
        int total = blockEntity.getContainerSize();
        for (int i = 0; i < VISIBLE_STORAGE_SLOTS; i++) {
            int slot = first + i;
            page.add(slot < total ? blockEntity.getItem(slot).copy() : ItemStack.EMPTY);
        }
        pageRevision++;
        ServerPlayNetworking.send(serverPlayer, new ChestPagePayload(containerId, pageRevision, scrollRow, total, page));
    }

    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (buttonId == SORT_ALL_BUTTON_ID) {
            if (!getCarried().isEmpty()) return false;
            if (!player.level().isClientSide()) {
                sortWholeChestAtomically();
                broadcastFullState();
            }
            return true;
        }
        if (buttonId < 0 || buttonId > getMaxScrollRows()) return false;
        int previous = scrollRow;
        setScrollRow(buttonId);
        if (scrollRow != previous) broadcastFullState();
        return true;
    }

    private void sortWholeChestAtomically() {
        Map<Item, Integer> creativeOrder = buildCreativeItemOrder();
        List<StackGroup> groups = new ArrayList<>();
        for (int slot = 0; slot < blockEntity.getContainerSize(); slot++) {
            ItemStack stack = blockEntity.getItem(slot);
            if (stack.isEmpty()) continue;
            StackGroup match = null;
            for (StackGroup group : groups) {
                if (ItemStack.isSameItemSameComponents(group.prototype, stack)) { match = group; break; }
            }
            if (match == null) {
                int categoryOrder = creativeOrder.getOrDefault(stack.getItem(), Integer.MAX_VALUE);
                match = new StackGroup(stack.copyWithCount(1), categoryOrder);
                groups.add(match);
            }
            match.totalCount += stack.getCount();
        }
        long needed = 0;
        for (StackGroup group : groups) {
            int max = Math.max(1, group.prototype.getMaxStackSize());
            needed += (group.totalCount + max - 1L) / max;
            if (needed > blockEntity.getContainerSize()) return;
        }
        groups.sort(Comparator.comparingInt(StackGroup::creativeOrder)
                .thenComparing(StackGroup::itemKey)
                .thenComparing(StackGroup::variantKey));
        int target = 0;
        for (StackGroup group : groups) {
            long remaining = group.totalCount;
            int max = Math.max(1, group.prototype.getMaxStackSize());
            while (remaining > 0 && target < blockEntity.getContainerSize()) {
                int count = (int)Math.min(max, remaining);
                blockEntity.setItem(target++, group.prototype.copyWithCount(count));
                remaining -= count;
            }
        }
        while (target < blockEntity.getContainerSize()) blockEntity.setItem(target++, ItemStack.EMPTY);
        blockEntity.setChanged();
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        if (slotIndex < 0 || slotIndex >= slots.size()) return ItemStack.EMPTY;
        Slot slot = slots.get(slotIndex);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (slotIndex < menuChestSlotCount) {
            if (!moveItemStackTo(stack, menuChestSlotCount, menuChestSlotCount + 36, true)) return ItemStack.EMPTY;
        } else if (!moveIntoWholeChest(stack)) return ItemStack.EMPTY;
        if (stack.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        slot.onTake(player, stack);
        return original;
    }

    private boolean moveIntoWholeChest(ItemStack source) {
        boolean moved = false;
        for (int i = 0; i < blockEntity.getContainerSize() && !source.isEmpty(); i++) {
            ItemStack target = blockEntity.getItem(i);
            if (!target.isEmpty() && ItemStack.isSameItemSameComponents(target, source)) {
                int amount = Math.min(target.getMaxStackSize() - target.getCount(), source.getCount());
                if (amount > 0) {
                    blockEntity.setItem(i, target.copyWithCount(target.getCount() + amount));
                    source.shrink(amount); moved = true;
                }
            }
        }
        for (int i = 0; i < blockEntity.getContainerSize() && !source.isEmpty(); i++) {
            if (blockEntity.getItem(i).isEmpty() && blockEntity.canPlaceItem(i, source)) {
                int amount = Math.min(source.getCount(), source.getMaxStackSize());
                blockEntity.setItem(i, source.copyWithCount(amount));
                source.shrink(amount); moved = true;
            }
        }
        return moved;
    }

    @Override public boolean stillValid(Player player) { return blockEntity.stillValid(player); }
    @Override public void removed(Player player) { super.removed(player); blockEntity.stopOpen(player); }

    private static Map<Item, Integer> buildCreativeItemOrder() {
        Map<Item, Integer> order = new IdentityHashMap<>();
        int index = 0;
        for (CreativeModeTab tab : CreativeModeTabs.allTabs()) {
            if (tab == CreativeModeTabs.searchTab()) continue;
            for (ItemStack displayStack : tab.getDisplayItems()) {
                order.putIfAbsent(displayStack.getItem(), index++);
            }
        }
        return order;
    }

    private static final class StackGroup {
        private final ItemStack prototype;
        private final int creativeOrder;
        private long totalCount;
        private StackGroup(ItemStack prototype, int creativeOrder) {
            this.prototype = prototype;
            this.creativeOrder = creativeOrder;
        }
        private int creativeOrder() { return creativeOrder; }
        private String itemKey() { return BuiltInRegistries.ITEM.getKey(prototype.getItem()).toString(); }
        private String variantKey() { return String.valueOf(prototype); }
    }

    private static final class PagedContainer implements Container {
        private final Container backing;
        private final boolean clientPage;
        private final ItemStack[] visibleItems;
        private int offset;
        private PagedContainer(Container backing, boolean clientPage) {
            this.backing = backing; this.clientPage = clientPage;
            visibleItems = clientPage ? new ItemStack[VISIBLE_STORAGE_SLOTS] : null;
            if (visibleItems != null) Arrays.fill(visibleItems, ItemStack.EMPTY);
        }
        private boolean isClientPage() { return clientPage; }
        private void setOffset(int value) { offset = Math.max(0, value); }
        private boolean validVisible(int slot) { return slot >= 0 && slot < VISIBLE_STORAGE_SLOTS; }
        private boolean validMapped(int slot) { int mapped = offset + slot; return validVisible(slot) && mapped >= 0 && mapped < backing.getContainerSize(); }
        private void applyClientPage(List<ItemStack> stacks) {
            if (!clientPage || stacks.size() != VISIBLE_STORAGE_SLOTS) return;
            for (int i = 0; i < VISIBLE_STORAGE_SLOTS; i++) visibleItems[i] = stacks.get(i) == null ? ItemStack.EMPTY : stacks.get(i).copy();
        }
        @Override public int getContainerSize() { return VISIBLE_STORAGE_SLOTS; }
        @Override public boolean isEmpty() { for (int i = 0; i < VISIBLE_STORAGE_SLOTS; i++) if (!getItem(i).isEmpty()) return false; return true; }
        @Override public ItemStack getItem(int slot) {
            if (!validVisible(slot)) return ItemStack.EMPTY;
            if (clientPage) return visibleItems[slot];
            return validMapped(slot) ? backing.getItem(offset + slot) : ItemStack.EMPTY;
        }
        @Override public ItemStack removeItem(int slot, int amount) {
            if (!validVisible(slot)) return ItemStack.EMPTY;
            if (clientPage) {
                ItemStack stack = visibleItems[slot];
                if (stack.isEmpty() || amount <= 0) return ItemStack.EMPTY;
                if (stack.getCount() <= amount) { visibleItems[slot] = ItemStack.EMPTY; return stack; }
                return stack.split(amount);
            }
            return validMapped(slot) ? backing.removeItem(offset + slot, amount) : ItemStack.EMPTY;
        }
        @Override public ItemStack removeItemNoUpdate(int slot) {
            if (!validVisible(slot)) return ItemStack.EMPTY;
            if (clientPage) { ItemStack result = visibleItems[slot]; visibleItems[slot] = ItemStack.EMPTY; return result; }
            return validMapped(slot) ? backing.removeItemNoUpdate(offset + slot) : ItemStack.EMPTY;
        }
        @Override public void setItem(int slot, ItemStack stack) {
            if (!validVisible(slot)) return;
            if (clientPage) visibleItems[slot] = stack == null ? ItemStack.EMPTY : stack.copy();
            else if (validMapped(slot)) backing.setItem(offset + slot, stack);
        }
        @Override public boolean canPlaceItem(int slot, ItemStack stack) {
            return validMapped(slot) && backing.canPlaceItem(offset + slot, stack);
        }
        @Override public void setChanged() { if (!clientPage) backing.setChanged(); }
        @Override public boolean stillValid(Player player) { return clientPage || backing.stillValid(player); }
        @Override public void clearContent() {
            if (clientPage) Arrays.fill(visibleItems, ItemStack.EMPTY);
            else for (int i = 0; i < VISIBLE_STORAGE_SLOTS; i++) if (validMapped(i)) backing.setItem(offset + i, ItemStack.EMPTY);
        }
        @Override public boolean canPlaceItem(int slot, ItemStack stack) {
            return validVisible(slot) && (clientPage || validMapped(slot) && backing.canPlaceItem(offset + slot, stack));
        }
    }
}
