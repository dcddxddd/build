package dev.moreexpandedchests.mixin;

import dev.moreexpandedchests.MoreExpandedChests;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** All More Chests drops are protected from fire, cactus and environmental item damage. */
@Mixin(ItemEntity.class)
public abstract class EchoChestItemDamageMixin {
    @Inject(method = "fireImmune", at = @At("HEAD"), cancellable = true)
    private void moreexpandedchests$chestItemsAreFireImmune(CallbackInfoReturnable<Boolean> cir) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (!self.getItem().isEmpty() && MoreExpandedChests.isChestItem(self.getItem().getItem())) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "hurtServer", at = @At("HEAD"), cancellable = true)
    private void moreexpandedchests$ignoreChestItemDamage(
            ServerLevel level,
            DamageSource source,
            float amount,
            CallbackInfoReturnable<Boolean> cir
    ) {
        ItemEntity self = (ItemEntity) (Object) this;
        if (!self.getItem().isEmpty() && MoreExpandedChests.isChestItem(self.getItem().getItem())) {
            // Item stacks remain collectible, but fire/cactus/other damage cannot erase them.
            cir.setReturnValue(false);
        }
    }
}
