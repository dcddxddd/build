package dev.moreexpandedchests.mixin;

import dev.moreexpandedchests.MoreExpandedChests;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Recovers an Echo Chest item entity at 30 blocks below the dimension's minimum Y.
 * Deliberate remove/discard/kill operations are intentionally not intercepted, so
 * trash slots and Creative clear actions can still delete the item normally.
 */
@Mixin(Entity.class)
public abstract class EchoChestEntityRemovalMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void moreexpandedchests$stopEchoChestAtVoidDepth(CallbackInfo ci) {
        if ((Object) this instanceof ItemEntity itemEntity
                && !itemEntity.getItem().isEmpty()
                && itemEntity.getItem().is(MoreExpandedChests.ECHO_CHEST.asItem())
                && itemEntity.getY() <= itemEntity.level().getMinY() - 30.0D) {
            itemEntity.setPos(itemEntity.getX(), itemEntity.level().getMinY() - 30.0D, itemEntity.getZ());
            itemEntity.setDeltaMovement(0.0D, 0.0D, 0.0D);
            itemEntity.setNoGravity(true);
        }
    }

    @Inject(method = "checkBelowWorld", at = @At("HEAD"), cancellable = true)
    private void moreexpandedchests$recoverEchoChestFromVoid(CallbackInfo ci) {
        if ((Object) this instanceof ItemEntity itemEntity
                && !itemEntity.getItem().isEmpty()
                && itemEntity.getItem().is(MoreExpandedChests.ECHO_CHEST.asItem())
                && itemEntity.getY() < itemEntity.level().getMinY() - 30.0D) {
            itemEntity.setPos(itemEntity.getX(), itemEntity.level().getMinY() - 30.0D, itemEntity.getZ());
            itemEntity.setDeltaMovement(0.0D, 0.0D, 0.0D);
            itemEntity.setNoGravity(true);
            ci.cancel();
        }
    }
}
