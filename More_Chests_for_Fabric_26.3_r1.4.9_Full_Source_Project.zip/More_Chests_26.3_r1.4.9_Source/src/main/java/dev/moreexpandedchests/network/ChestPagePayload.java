package dev.moreexpandedchests.network;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import dev.moreexpandedchests.MoreExpandedChests;
import java.util.ArrayList;
import java.util.List;

public record ChestPagePayload(int containerId, int revision, int scrollRow, int totalSlots, List<ItemStack> stacks)
        implements CustomPacketPayload {
    public static final int MAX_STORAGE_SLOTS = 4096;
    public static final int PAGE_SLOTS = 54;
    public static final Type<ChestPagePayload> ID = new Type<>(MoreExpandedChests.id("chest_page"));
    public static final StreamCodec<RegistryFriendlyByteBuf, ChestPagePayload> CODEC = new StreamCodec<>() {
        @Override public ChestPagePayload decode(RegistryFriendlyByteBuf buffer) {
            int containerId = ByteBufCodecs.VAR_INT.decode(buffer);
            int revision = ByteBufCodecs.VAR_INT.decode(buffer);
            int scrollRow = ByteBufCodecs.VAR_INT.decode(buffer);
            int totalSlots = ByteBufCodecs.VAR_INT.decode(buffer);
            int count = ByteBufCodecs.VAR_INT.decode(buffer);
            validate(totalSlots, scrollRow, count);
            List<ItemStack> items = new ArrayList<>(count);
            for (int i = 0; i < count; i++) items.add(ItemStack.OPTIONAL_STREAM_CODEC.decode(buffer));
            return new ChestPagePayload(containerId, revision, scrollRow, totalSlots, items);
        }
        @Override public void encode(RegistryFriendlyByteBuf buffer, ChestPagePayload payload) {
            validate(payload.totalSlots, payload.scrollRow, payload.stacks.size());
            ByteBufCodecs.VAR_INT.encode(buffer, payload.containerId);
            ByteBufCodecs.VAR_INT.encode(buffer, payload.revision);
            ByteBufCodecs.VAR_INT.encode(buffer, payload.scrollRow);
            ByteBufCodecs.VAR_INT.encode(buffer, payload.totalSlots);
            ByteBufCodecs.VAR_INT.encode(buffer, payload.stacks.size());
            for (ItemStack stack : payload.stacks) ItemStack.OPTIONAL_STREAM_CODEC.encode(buffer, stack);
        }
    };
    public ChestPagePayload {
        validate(totalSlots, scrollRow, stacks.size());
        List<ItemStack> copies = new ArrayList<>(stacks.size());
        for (ItemStack stack : stacks) copies.add(stack == null ? ItemStack.EMPTY : stack.copy());
        stacks = List.copyOf(copies);
    }
    private static void validate(int total, int row, int count) {
        if (total < 4 || total > MAX_STORAGE_SLOTS) throw new IllegalArgumentException("Invalid chest size: " + total);
        int totalRows = (total + 8) / 9;
        int pageCount = Math.max(1, (totalRows + 5) / 6);
        int maxRow = (pageCount - 1) * 6;
        if (row < 0 || row > maxRow) throw new IllegalArgumentException("Invalid scroll row: " + row);
        if (count != PAGE_SLOTS) throw new IllegalArgumentException("Invalid page size: " + count);
    }
    @Override public Type<? extends CustomPacketPayload> type() { return ID; }
}
