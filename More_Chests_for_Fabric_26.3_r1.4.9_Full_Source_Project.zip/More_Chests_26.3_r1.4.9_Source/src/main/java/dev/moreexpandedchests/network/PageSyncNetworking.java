package dev.moreexpandedchests.network;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
public final class PageSyncNetworking implements ModInitializer {
    @Override public void onInitialize() { PayloadTypeRegistry.clientboundPlay().register(ChestPagePayload.ID, ChestPagePayload.CODEC); }
}
