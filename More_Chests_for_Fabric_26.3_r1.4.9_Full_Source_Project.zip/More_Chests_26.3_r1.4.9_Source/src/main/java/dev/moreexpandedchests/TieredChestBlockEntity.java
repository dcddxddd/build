package dev.moreexpandedchests;

import net.fabricmc.fabric.api.menu.v1.ExtendedMenuProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponentGetter;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Containers;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.LidBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.Level;
import net.minecraft.world.Container;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.server.level.ServerLevel;
import dev.moreexpandedchests.storage.EchoChestSavedData;

public final class TieredChestBlockEntity extends BlockEntity implements ExtendedMenuProvider<BlockPos>, WorldlyContainer, LidBlockEntity {
    private static final Direction[] PARTNER_DIRECTIONS = {Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
    private final SimpleContainer inventory;
    private final int[] singleAccessibleSlots;
    private final int[] doubleAccessibleSlots;
    private int openers;
    private int glassDisplayIndex;
    private ItemStack clientGlassDisplayStack = ItemStack.EMPTY;

    public TieredChestBlockEntity(BlockPos position, BlockState state) {
        super(MoreExpandedChests.CHEST_BLOCK_ENTITY, position, state);
        Block block = state.getBlock();
        int slots = block instanceof TieredChestBlock chestBlock ? chestBlock.slots() : 36;
        inventory = new SimpleContainer(slots);
        singleAccessibleSlots = createSlotArray(slots);
        doubleAccessibleSlots = createSlotArray(slots * 2);
    }

    private static int[] createSlotArray(int size) {
        int[] slots = new int[size];
        for (int i = 0; i < size; i++) slots[i] = i;
        return slots;
    }

    public SimpleContainer inventory() { return inventory; }

    /** Vanilla 26.3 chest renderers consume this openness value through LidBlockEntity.
     * The server advances OPEN_STAGE in four deterministic steps; normalize it to [0, 1]
     * so a renderer can animate the vanilla chest lid without reading server-only state.
     */
    @Override
    public float getOpenNess(float partialTick) {
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof TieredChestBlock)) return 0.0F;
        return Math.max(0.0F, Math.min(1.0F, state.getValue(TieredChestBlock.OPEN_STAGE) / 3.0F));
    }
    public boolean isDoubleChest() { return findPartner() != null; }
    public int glassDisplayIndex() { return glassDisplayIndex; }
    public ItemStack getGlassDisplayStack() {
        if (getBlockState().getBlock() != MoreExpandedChests.GLASS_CHEST) return ItemStack.EMPTY;
        // The glass inventory is server-authoritative; clients render only the synchronized preview stack.
        if (level != null && level.isClientSide()) return clientGlassDisplayStack.copy();
        List<ItemStack> present = new ArrayList<>();
        // Use the logical container view so a paired glass chest previews both halves.
        // getItem() also keeps this code compatible with future container-backed tiers.
        int size = getContainerSize();
        for (int slot = 0; slot < size; slot++) {
            ItemStack stack = getItem(slot);
            if (!stack.isEmpty()) present.add(stack);
        }
        if (present.isEmpty()) return ItemStack.EMPTY;
        return present.get(Math.floorMod(glassDisplayIndex, present.size())).copyWithCount(1);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, TieredChestBlockEntity chest) {
        long time = level.getGameTime();
        chest.refreshChestTypeState();
        if (state.getBlock() == MoreExpandedChests.EMERALD_CHEST && time % 1200L == 0L) {
            chest.produceEmeralds(level);
        }
        if (state.getBlock() == MoreExpandedChests.GLASS_CHEST && time % 20L == 0L) {
            // Empty ItemStack is not a valid ItemStack.CODEC payload in 26.3.
            // Rotate only when a real item exists; empty previews are omitted from update tags.
            if (!chest.getGlassDisplayStack().isEmpty()) {
                chest.glassDisplayIndex++;
                chest.setChanged();
            }
        }
        if (state.getBlock() == MoreExpandedChests.AMETHYST_CHEST && time % 40L == 0L) {
            chest.pullMatchingItemsFromNearbyContainers();
        }
        if (state.getBlock() == MoreExpandedChests.COPPER_CHEST && time % 24000L == 0L
                && level.getRandom().nextFloat() < 0.30F) {
            int oxidation = state.getValue(TieredChestBlock.OXIDATION);
            if (oxidation < 3) {
                int nextOxidation = oxidation + 1;
                level.setBlock(pos, state.setValue(TieredChestBlock.OXIDATION, nextOxidation), 3);
                for (Direction direction : PARTNER_DIRECTIONS) {
                    BlockPos adjacentPos = pos.relative(direction);
                    BlockState adjacent = level.getBlockState(adjacentPos);
                    if (adjacent.getBlock() == MoreExpandedChests.COPPER_CHEST
                            && adjacent.getValue(TieredChestBlock.OXIDATION) < nextOxidation) {
                        level.setBlock(adjacentPos, adjacent.setValue(TieredChestBlock.OXIDATION, nextOxidation), 3);
                    }
                }
            }
        }
    }


    /** Keeps the vanilla-compatible SINGLE/LEFT/RIGHT state in sync with the logical pair.
     * Visible half-meshes are intentionally added in the following resource/rendering pass.
     */
    private void refreshChestTypeState() {
        if (level == null || level.isClientSide()) return;
        TieredChestBlockEntity partner = findPartner();
        BlockState own = level.getBlockState(worldPosition);
        if (!(own.getBlock() instanceof TieredChestBlock)) return;

        ChestType ownType = ChestType.SINGLE;
        ChestType partnerType = ChestType.SINGLE;
        if (partner != null) {
            Direction facing = own.getValue(TieredChestBlock.FACING);
            Direction toPartner = null;
            for (Direction direction : PARTNER_DIRECTIONS) {
                if (worldPosition.relative(direction).equals(partner.getBlockPos())) {
                    toPartner = direction;
                    break;
                }
            }
            // Looking at the front: a partner on the viewer's right makes this the LEFT half.
            ownType = toPartner == facing.getClockWise() ? ChestType.LEFT : ChestType.RIGHT;
            partnerType = ownType == ChestType.LEFT ? ChestType.RIGHT : ChestType.LEFT;
        }

        if (own.getValue(TieredChestBlock.CHEST_TYPE) != ownType) {
            level.setBlock(worldPosition, own.setValue(TieredChestBlock.CHEST_TYPE, ownType), 3);
        }
        if (partner != null) {
            BlockState other = level.getBlockState(partner.getBlockPos());
            if (other.getBlock() instanceof TieredChestBlock
                    && other.getValue(TieredChestBlock.CHEST_TYPE) != partnerType) {
                level.setBlock(partner.getBlockPos(), other.setValue(TieredChestBlock.CHEST_TYPE, partnerType), 3);
            }
        }
    }

    private void produceEmeralds(Level level) {
        ItemStack emeraldPrototype = new ItemStack(Items.EMERALD);
        int freeCapacity = 0;
        for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
            ItemStack current = inventory.getItem(slot);
            if (current.isEmpty()) {
                freeCapacity += emeraldPrototype.getMaxStackSize();
            } else if (ItemStack.isSameItemSameComponents(current, emeraldPrototype)) {
                freeCapacity += Math.max(0, current.getMaxStackSize() - current.getCount());
            }
        }
        // Do not generate items that cannot fit: full chests pause production instead of voiding emeralds.
        int amount = level.getRandom().nextInt(Math.min(64, freeCapacity) + 1);
        if (amount == 0) return;
        ItemStack incoming = new ItemStack(Items.EMERALD, amount);
        for (int slot = 0; slot < inventory.getContainerSize() && !incoming.isEmpty(); slot++) {
            ItemStack current = inventory.getItem(slot);
            if (current.isEmpty()) {
                int moved = Math.min(incoming.getCount(), incoming.getMaxStackSize());
                inventory.setItem(slot, incoming.copyWithCount(moved));
                incoming.shrink(moved);
            } else if (ItemStack.isSameItemSameComponents(current, emeraldPrototype)) {
                int moved = Math.min(incoming.getCount(), current.getMaxStackSize() - current.getCount());
                if (moved > 0) {
                    current.grow(moved);
                    incoming.shrink(moved);
                }
            }
        }
        setChanged();
    }

    private void pullMatchingItemsFromNearbyContainers() {
        if (level == null || level.isClientSide()) return;

        List<ItemStack> trackedTypes = new ArrayList<>();
        for (ItemStack stack : inventory.getItems()) {
            // Each item+component variant is evaluated independently. Multiple local stacks
            // of the same type must not give that type extra weight in source selection.
            if (!stack.isEmpty() && !matchesTracked(stack, trackedTypes)) {
                trackedTypes.add(stack.copyWithCount(1));
            }
        }
        if (trackedTypes.isEmpty()) return;

        List<ContainerCandidate> candidates = new ArrayList<>();
        BlockPos origin = getBlockPos();
        // A 10×10×10 cube: offsets -5 through +4 on each axis.
        for (int dx = -5; dx <= 4; dx++) {
            for (int dy = -5; dy <= 4; dy++) {
                for (int dz = -5; dz <= 4; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    BlockPos targetPos = origin.offset(dx, dy, dz);
                    if (!level.hasChunkAt(targetPos)) continue;

                    BlockEntity targetEntity = level.getBlockEntity(targetPos);
                    if (!(targetEntity instanceof Container target) || targetEntity == this) continue;
                    if (targetEntity instanceof TieredChestBlockEntity tiered) {
                        if (tiered.getBlockState().getBlock() == MoreExpandedChests.AMETHYST_CHEST) continue;
                        // A paired custom chest exposes the combined inventory from both halves.
                        // Visit only its canonical first half so the same inventory is not counted twice.
                        TieredChestBlockEntity partner = tiered.findPartner();
                        if (partner != null && !tiered.comesFirst(partner)) continue;
                    }

                    int[] countsByType = new int[trackedTypes.size()];
                    boolean hasMatchingItems = false;
                    for (int typeIndex = 0; typeIndex < trackedTypes.size(); typeIndex++) {
                        countsByType[typeIndex] = countMatching(target, trackedTypes.get(typeIndex));
                        hasMatchingItems |= countsByType[typeIndex] > 0;
                    }
                    if (hasMatchingItems) {
                        double distanceSquared = origin.distSqr(targetPos);
                        candidates.add(new ContainerCandidate(target, targetPos.immutable(), countsByType, distanceSquared));
                    }
                }
            }
        }
        if (candidates.isEmpty()) return;

        // For each selected item type, choose exactly one source container: the container
        // with the largest quantity of that type. If tied, prefer the nearest, then the
        // lowest packed block position for deterministic behavior.
        int[] winningCandidateByType = new int[trackedTypes.size()];
        int[] winningCountByType = new int[trackedTypes.size()];
        java.util.Arrays.fill(winningCandidateByType, -1);
        for (int candidateIndex = 0; candidateIndex < candidates.size(); candidateIndex++) {
            ContainerCandidate candidate = candidates.get(candidateIndex);
            for (int typeIndex = 0; typeIndex < trackedTypes.size(); typeIndex++) {
                int count = candidate.matchingCounts()[typeIndex];
                if (count <= 0) continue;
                int currentWinner = winningCandidateByType[typeIndex];
                if (currentWinner < 0 || count > winningCountByType[typeIndex]) {
                    winningCandidateByType[typeIndex] = candidateIndex;
                    winningCountByType[typeIndex] = count;
                } else if (count == winningCountByType[typeIndex]) {
                    ContainerCandidate incumbent = candidates.get(currentWinner);
                    if (candidate.distanceSquared() < incumbent.distanceSquared()
                            || (candidate.distanceSquared() == incumbent.distanceSquared()
                            && candidate.position().asLong() < incumbent.position().asLong())) {
                        winningCandidateByType[typeIndex] = candidateIndex;
                    }
                }
            }
        }

        boolean changed = false;
        for (int candidateIndex = 0; candidateIndex < candidates.size(); candidateIndex++) {
            boolean selectedAsWinner = false;
            for (int winner : winningCandidateByType) {
                if (winner == candidateIndex) {
                    selectedAsWinner = true;
                    break;
                }
            }
            if (!selectedAsWinner) continue;

            ContainerCandidate candidate = candidates.get(candidateIndex);
            Container source = candidate.container();
            for (int sourceSlot = 0; sourceSlot < source.getContainerSize(); sourceSlot++) {
                ItemStack sourceStack = source.getItem(sourceSlot);
                if (sourceStack.isEmpty()) continue;
                int typeIndex = findTrackedType(sourceStack, trackedTypes);
                if (typeIndex < 0 || winningCandidateByType[typeIndex] != candidateIndex) continue;

                int destinationSlot = findCompatibleDestination(sourceStack);
                if (destinationSlot < 0) continue;
                ItemStack destination = inventory.getItem(destinationSlot);
                int free = destination.isEmpty() ? sourceStack.getMaxStackSize()
                        : destination.getMaxStackSize() - destination.getCount();
                int move = Math.min(free, sourceStack.getCount());
                if (move <= 0) continue;

                ItemStack extracted = source.removeItem(sourceSlot, move);
                if (extracted.isEmpty()) continue;
                if (destination.isEmpty()) inventory.setItem(destinationSlot, extracted.copy());
                else destination.grow(extracted.getCount());
                source.setChanged();
                changed = true;
            }
        }
        if (changed) setChanged();
    }

    private int findCompatibleDestination(ItemStack stack) {
        int firstEmpty = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack existing = inventory.getItem(i);
            if (!existing.isEmpty() && ItemStack.isSameItemSameComponents(existing, stack)
                    && existing.getCount() < existing.getMaxStackSize()) return i;
            if (existing.isEmpty() && firstEmpty < 0) firstEmpty = i;
        }
        // Empty slots may receive another stack of a type already selected in this chest.
        return firstEmpty;
    }

    private static int countMatching(Container container, ItemStack type) {
        int count = 0;
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack stack = container.getItem(i);
            if (!stack.isEmpty() && ItemStack.isSameItemSameComponents(stack, type)) count += stack.getCount();
        }
        return count;
    }

    private static int findTrackedType(ItemStack stack, List<ItemStack> types) {
        for (int i = 0; i < types.size(); i++) {
            if (ItemStack.isSameItemSameComponents(stack, types.get(i))) return i;
        }
        return -1;
    }

    private static boolean matchesTracked(ItemStack stack, List<ItemStack> types) {
        return findTrackedType(stack, types) >= 0;
    }

    private record ContainerCandidate(Container container, BlockPos position, int[] matchingCounts,
                                       double distanceSquared) {}

    private TieredChestBlockEntity selectCandidate() {
        if (level == null) return null;
        BlockState ownState = getBlockState();
        Block ownBlock = ownState.getBlock();
        Direction facing = ownState.getValue(TieredChestBlock.FACING);
        TieredChestBlockEntity selected = null;
        // A double chest may only join side-by-side: same tier, same facing, and
        // an adjacency axis perpendicular to the front/back axis. Front/back
        // neighbors must remain independent containers.
        for (Direction direction : PARTNER_DIRECTIONS) {
            if (direction.getAxis() == facing.getAxis()) continue;
            BlockEntity adjacent = level.getBlockEntity(getBlockPos().relative(direction));
            if (!(adjacent instanceof TieredChestBlockEntity chest)) continue;
            BlockState otherState = chest.getBlockState();
            if (otherState.getBlock() != ownBlock
                    || otherState.getValue(TieredChestBlock.FACING) != facing) continue;
            if (selected == null || chest.getBlockPos().asLong() < selected.getBlockPos().asLong()) {
                selected = chest;
            }
        }
        return selected;
    }

    private TieredChestBlockEntity findPartner() {
        // Echo storage is a single cross-dimensional network; amethyst storage is intentionally four slots.
        if (getBlockState().getBlock() == MoreExpandedChests.ECHO_CHEST
                || getBlockState().getBlock() == MoreExpandedChests.AMETHYST_CHEST) return null;
        TieredChestBlockEntity candidate = selectCandidate();
        return candidate != null && candidate.selectCandidate() == this ? candidate : null;
    }

    private boolean comesFirst(TieredChestBlockEntity partner) {
        return Long.compare(getBlockPos().asLong(), partner.getBlockPos().asLong()) <= 0;
    }
    private TieredChestBlockEntity firstHalf(TieredChestBlockEntity partner) { return comesFirst(partner) ? this : partner; }
    private TieredChestBlockEntity secondHalf(TieredChestBlockEntity partner) { return comesFirst(partner) ? partner : this; }
    private SimpleContainer activeInventory() {
        if (getBlockState().getBlock() == MoreExpandedChests.ECHO_CHEST && level instanceof ServerLevel serverLevel) {
            return EchoChestSavedData.get(serverLevel.getServer()).inventory();
        }
        return inventory;
    }

    private int localSize() {
        return getBlockState().getBlock() == MoreExpandedChests.ECHO_CHEST
                ? EchoChestSavedData.SLOT_COUNT : inventory.getContainerSize();
    }
    private TieredChestBlockEntity halfForSlot(int slot, TieredChestBlockEntity partner) {
        return partner == null ? this : (slot < localSize() ? firstHalf(partner) : secondHalf(partner));
    }
    private int localSlot(int slot, TieredChestBlockEntity partner) {
        return partner == null || slot < localSize() ? slot : slot - localSize();
    }
    private boolean validSlot(int slot, TieredChestBlockEntity partner) {
        return slot >= 0 && slot < (partner == null ? localSize() : localSize() * 2);
    }

    private ItemStack rawGetItem(int slot) { return activeInventory().getItem(slot); }
    private ItemStack rawRemoveItem(int slot, int amount) {
        ItemStack result = activeInventory().removeItem(slot, amount); setChanged(); return result;
    }
    private ItemStack rawRemoveItemNoUpdate(int slot) {
        ItemStack result = activeInventory().removeItemNoUpdate(slot); setChanged(); return result;
    }
    private void rawSetItem(int slot, ItemStack stack) { activeInventory().setItem(slot, stack); setChanged(); }
    private boolean rawCanPlaceItem(int slot, ItemStack stack) {
        if (getBlockState().getBlock() == MoreExpandedChests.COAL_CHEST
                && stack.getItem() != Items.COAL) return false;
        if (getBlockState().getBlock() == MoreExpandedChests.CHARCOAL_CHEST
                && stack.getItem() != Items.CHARCOAL) return false;
        return activeInventory().canPlaceItem(slot, stack);
    }

    public void startOpen(Player player) {
        if (level != null && !level.isClientSide()) changeOpeners(1);
    }
    public void stopOpen(Player player) {
        if (level != null && !level.isClientSide()) changeOpeners(-1);
    }

    private void changeOpeners(int delta) {
        TieredChestBlockEntity partner = findPartner();
        TieredChestBlockEntity first = partner == null ? this : firstHalf(partner);
        TieredChestBlockEntity second = partner == null ? null : secondHalf(partner);
        int previous = first.openers;
        first.openers = Math.max(0, first.openers + delta);
        if (second != null) second.openers = first.openers;
        if (previous == 0 && first.openers > 0) {
            level.playSound(null, first.getBlockPos(), SoundEvents.CHEST_OPEN, SoundSource.BLOCKS, 0.5F, 1.0F);
        } else if (previous > 0 && first.openers == 0) {
            level.playSound(null, first.getBlockPos(), SoundEvents.CHEST_CLOSE, SoundSource.BLOCKS, 0.5F, 1.0F);
        }
        first.scheduleOpenAnimation();
        if (second != null) second.scheduleOpenAnimation();
    }

    private void scheduleOpenAnimation() {
        if (level != null && !level.isClientSide()) level.scheduleTick(worldPosition, getBlockState().getBlock(), 1);
    }

    public void advanceOpenAnimation() {
        if (level == null || level.isClientSide()) return;
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof TieredChestBlock)) return;
        int current = state.getValue(TieredChestBlock.OPEN_STAGE);
        int target = openers > 0 ? 3 : 0;
        if (current == target) return;
        int next = current + Integer.compare(target, current);
        level.setBlock(worldPosition, state.setValue(TieredChestBlock.OPEN_STAGE, next), 3);
        if (next != target) scheduleOpenAnimation();
    }

    @Override
    public Component getDisplayName() {
        Block block = getBlockState().getBlock();
        return Component.translatable("container.moreexpandedchests.title", block.getName(), getContainerSize());
    }

    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new TieredChestMenu(containerId, playerInventory, this);
    }

    @Override
    public BlockPos getScreenOpeningData(ServerPlayer player) { return getBlockPos(); }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        if (getBlockState().getBlock() != MoreExpandedChests.ECHO_CHEST) {
            ContainerHelper.saveAllItems(output.child("inventory"), inventory.getItems());
        }
        output.putInt("glassDisplayIndex", glassDisplayIndex);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        if (getBlockState().getBlock() != MoreExpandedChests.ECHO_CHEST) {
            ContainerHelper.loadAllItems(input.childOrEmpty("inventory"), inventory.getItems());
        }
        input.getInt("glassDisplayIndex").ifPresent(value -> glassDisplayIndex = Math.max(0, value));
        // A missing preview tag means the server has no displayable stack.
        clientGlassDisplayStack = ItemStack.EMPTY;
        input.read("glassDisplayStack", ItemStack.CODEC).ifPresent(stack -> clientGlassDisplayStack = stack);
    }

    /**
     * Synchronize only the public glass-chest preview, not the complete private inventory.
     * This packet is also used for initial client chunk state.
     */
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        if (getBlockState().getBlock() != MoreExpandedChests.GLASS_CHEST) {
            return super.getUpdateTag(registries);
        }
        CompoundTag tag = new CompoundTag();
        tag.putInt("glassDisplayIndex", glassDisplayIndex);
        ItemStack displayStack = getGlassDisplayStack();
        // ItemStack.EMPTY encodes as minecraft:air with count 0, rejected by the 26.3 codec.
        // Omitting this optional preview key is the valid representation of an empty glass chest.
        if (!displayStack.isEmpty()) {
            // Mods may attach components that are not serializable through the vanilla NBT codec.
            // A preview is cosmetic, so omit it on codec failure rather than crashing chunk sync.
            ItemStack.CODEC.encodeStart(NbtOps.INSTANCE, displayStack)
                    .result()
                    .ifPresent(encoded -> tag.put("glassDisplayStack", encoded));
        }
        return tag;
    }

    /**
     * A gold chest behaves like a shulker box: its inventory becomes the item container
     * component when the block is picked up and is restored when that item is placed.
     */
    @Override
    protected void applyImplicitComponents(DataComponentGetter components) {
        super.applyImplicitComponents(components);
        if (getBlockState().getBlock() == MoreExpandedChests.GOLD_CHEST
                || getBlockState().getBlock() == MoreExpandedChests.AMETHYST_CHEST) {
            ItemContainerContents contents = components.get(DataComponents.CONTAINER);
            if (contents != null) contents.copyInto(inventory.getItems());
        }
    }

    @Override
    protected void collectImplicitComponents(DataComponentMap.Builder components) {
        super.collectImplicitComponents(components);
        if (getBlockState().getBlock() == MoreExpandedChests.GOLD_CHEST
                || getBlockState().getBlock() == MoreExpandedChests.AMETHYST_CHEST) {
            components.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(inventory.getItems()));
        }
    }

    @Override
    public void setChanged() {
        super.setChanged();
        if (level instanceof ServerLevel serverLevel && getBlockState().getBlock() == MoreExpandedChests.ECHO_CHEST) {
            EchoChestSavedData.get(serverLevel.getServer()).markDirty();
        }
        // Keep the glass chest's displayed item and one-second carousel synchronized to clients.
        if (level != null && !level.isClientSide() && getBlockState().getBlock() == MoreExpandedChests.GLASS_CHEST) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    public void preRemoveSideEffects(BlockPos position, BlockState state) {
        if (level == null) return;
        Block block = state.getBlock();
        // Gold/amethyst inventory is carried by its dropped item. Coal and charcoal
        // contents are handled by their explicit player-break drop path. Echo inventory
        // remains in the world-global SavedData network.
        if (block != MoreExpandedChests.GOLD_CHEST && block != MoreExpandedChests.AMETHYST_CHEST
                && block != MoreExpandedChests.ECHO_CHEST) {
            Containers.dropContents(level, position, inventory);
        }
    }

    @Override
    public int getContainerSize() {
        return findPartner() == null ? localSize() : localSize() * 2;
    }

    @Override
    public boolean isEmpty() {
        TieredChestBlockEntity partner = findPartner();
        SimpleContainer ownInventory = activeInventory();
        if (partner == null) return ownInventory.isEmpty();
        return ownInventory.isEmpty() && partner.activeInventory().isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        TieredChestBlockEntity partner = findPartner();
        return validSlot(slot, partner) ? halfForSlot(slot, partner).rawGetItem(localSlot(slot, partner)) : ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        TieredChestBlockEntity partner = findPartner();
        return validSlot(slot, partner) ? halfForSlot(slot, partner).rawRemoveItem(localSlot(slot, partner), amount) : ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        TieredChestBlockEntity partner = findPartner();
        return validSlot(slot, partner) ? halfForSlot(slot, partner).rawRemoveItemNoUpdate(localSlot(slot, partner)) : ItemStack.EMPTY;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        TieredChestBlockEntity partner = findPartner();
        if (validSlot(slot, partner)) halfForSlot(slot, partner).rawSetItem(localSlot(slot, partner), stack);
    }

    @Override
    public boolean stillValid(Player player) {
        if (level == null || level.getBlockEntity(worldPosition) != this) return false;
        double dx = player.getX() - (worldPosition.getX() + 0.5D);
        double dy = player.getY() - (worldPosition.getY() + 0.5D);
        double dz = player.getZ() - (worldPosition.getZ() + 0.5D);
        return dx * dx + dy * dy + dz * dz <= 64.0D;
    }

    @Override
    public void clearContent() {
        TieredChestBlockEntity partner = findPartner();
        activeInventory().clearContent();
        if (partner != null) partner.activeInventory().clearContent();
        setChanged();
        if (partner != null) partner.setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        TieredChestBlockEntity partner = findPartner();
        return validSlot(slot, partner) && halfForSlot(slot, partner).rawCanPlaceItem(localSlot(slot, partner), stack);
    }

    @Override
    public int[] getSlotsForFace(Direction direction) {
        return findPartner() == null ? singleAccessibleSlots : doubleAccessibleSlots;
    }
    @Override
    public boolean canPlaceItemThroughFace(int slot, ItemStack stack, Direction direction) { return canPlaceItem(slot, stack); }
    @Override
    public boolean canTakeItemThroughFace(int slot, ItemStack stack, Direction direction) { return validSlot(slot, findPartner()); }
}
