package dev.moreexpandedchests;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.Containers;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import java.util.List;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

public final class TieredChestBlock extends BaseEntityBlock {
    public static final IntegerProperty OPEN_STAGE = IntegerProperty.create("open_stage", 0, 3);
    public static final IntegerProperty OXIDATION = IntegerProperty.create("oxidation", 0, 3);
    public static final EnumProperty<Direction> FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final EnumProperty<ChestType> CHEST_TYPE = BlockStateProperties.CHEST_TYPE;
    private static final Direction[] PARTNER_DIRECTIONS = {Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};

    private final int slots;
    private final boolean fireResistant;

    public TieredChestBlock(BlockBehaviour.Properties properties, int slots, boolean fireResistant) {
        super(properties);
        this.slots = slots;
        this.fireResistant = fireResistant;
    }

    public int slots() { return slots; }
    public boolean fireResistantTier() { return fireResistant; }
    public boolean isCopperTier() { return this == MoreExpandedChests.COPPER_CHEST; }

    // Custom constructor fields are fixed per registered block instance. The codec
    // uses a unit instance because this block has no data-driven constructor fields.
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return MapCodec.unit(new TieredChestBlock(BlockBehaviour.Properties.of(), slots, fireResistant));
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, OPEN_STAGE, OXIDATION, CHEST_TYPE);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Direction facing = context.getHorizontalDirection().getOpposite();
        Level level = context.getLevel();
        BlockPos position = context.getClickedPos();
        int inheritedOxidation = 0;
        boolean inheritedFacing = false;
        for (Direction direction : PARTNER_DIRECTIONS) {
            BlockState adjacentState = level.getBlockState(position.relative(direction));
            if (adjacentState.getBlock() == this) {
                if (!inheritedFacing) {
                    facing = adjacentState.getValue(FACING);
                    inheritedFacing = true;
                }
                if (isCopperTier()) {
                    inheritedOxidation = Math.max(inheritedOxidation, adjacentState.getValue(OXIDATION));
                }
            }
        }
        return defaultBlockState()
                .setValue(FACING, facing)
                .setValue(OPEN_STAGE, 0)
                .setValue(OXIDATION, inheritedOxidation)
                .setValue(CHEST_TYPE, ChestType.SINGLE);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos position,
                                                Player player, BlockHitResult hitResult) {
        if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
            // Keep the placement facing. Rotating the block on every interaction made
            // the chest front point away from the player and desynchronized paired halves.
            BlockEntity blockEntity = level.getBlockEntity(position);
            if (blockEntity instanceof MenuProvider menuProvider) serverPlayer.openMenu(menuProvider);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos position, RandomSource random) {
        BlockEntity blockEntity = level.getBlockEntity(position);
        if (blockEntity instanceof TieredChestBlockEntity chest) chest.advanceOpenAnimation();
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide() || type != MoreExpandedChests.CHEST_BLOCK_ENTITY) return null;
        return createTickerHelper(type, MoreExpandedChests.CHEST_BLOCK_ENTITY, TieredChestBlockEntity::serverTick);
    }

    @Override
    public float getProvidedEnchantmentPower(BlockState state, LevelReader level, BlockPos pos) {
        // A lapis chest is a full-strength enchanting provider when placed in the power ring.
        return this == MoreExpandedChests.LAPIS_CHEST ? 15.0F : 0.0F;
    }


    @Override
    public BlockState playerWillDestroy(Level level, BlockPos position, BlockState state, Player player) {
        if (!level.isClientSide()) {
            BlockEntity blockEntity = level.getBlockEntity(position);
            // Creative-mode block removal normally suppresses loot. These three tiers
            // intentionally behave like shulker boxes and retain their inventory.
            if (player.getAbilities().instabuild
                    && (this == MoreExpandedChests.GOLD_CHEST || this == MoreExpandedChests.AMETHYST_CHEST)
                    && blockEntity instanceof TieredChestBlockEntity chest) {
                ItemStack drop = new ItemStack(this);
                drop.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(chest.inventory().getItems()));
                level.addFreshEntity(new net.minecraft.world.entity.item.ItemEntity(level,
                        position.getX() + 0.5D, position.getY() + 0.5D, position.getZ() + 0.5D, drop));
            }
        }
        return super.playerWillDestroy(level, position, state, player);
    }

    @Override
    protected List<ItemStack> getDrops(BlockState state, LootParams.Builder params) {
        if (this == MoreExpandedChests.ECHO_CHEST) {
            // Vanilla has no separate needs_netherite_tool block tag. Enforce the requested
            // exact tool at the loot boundary: a Netherite Pickaxe is required for an Echo drop.
            ItemStack tool = params.getOptionalParameter(LootContextParams.TOOL);
            if (tool == null || !tool.is(net.minecraft.world.item.Items.NETHERITE_PICKAXE)) {
                return List.of();
            }
        }
        if (this != MoreExpandedChests.GOLD_CHEST && this != MoreExpandedChests.AMETHYST_CHEST) {
            return super.getDrops(state, params);
        }

        // Gold and amethyst chests keep their contents in the dropped block item like a shulker box.
        // Do this in the block's drop path rather than relying on a loot-table component
        // copy after the block entity has been removed.
        ItemStack droppedChest = new ItemStack(this);
        BlockEntity blockEntity = params.getOptionalParameter(LootContextParams.BLOCK_ENTITY);
        if (blockEntity instanceof TieredChestBlockEntity chest) {
            // Copy each slot into a detached list before block-entity removal. This avoids
            // depending on the mutable SimpleContainer after the block is removed.
            List<ItemStack> savedContents = new java.util.ArrayList<>(chest.inventory().getContainerSize());
            for (int slot = 0; slot < chest.inventory().getContainerSize(); slot++) {
                savedContents.add(chest.inventory().getItem(slot).copy());
            }
            droppedChest.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(savedContents));
        }
        return List.of(droppedChest);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos position, BlockState state) {
        return new TieredChestBlockEntity(position, state);
    }
}
