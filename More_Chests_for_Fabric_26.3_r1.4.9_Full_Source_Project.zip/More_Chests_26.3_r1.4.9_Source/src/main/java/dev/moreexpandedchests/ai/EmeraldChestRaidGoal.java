package dev.moreexpandedchests.ai;

import dev.moreexpandedchests.MoreExpandedChests;
import dev.moreexpandedchests.TieredChestBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.raid.Raider;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * A high-priority raid objective for illagers: occasionally approach and destroy
 * a nearby Emerald Chest. While this objective is active, ordinary creature
 * retaliation targets are cleared so another mob cannot pull the raider away.
 */
public final class EmeraldChestRaidGoal extends Goal {
    private static final int SEARCH_XZ = 12;
    private static final int SEARCH_Y = 6;
    private static final float ACQUIRE_CHANCE = 0.15F;
    private static final int FAILED_SEARCH_COOLDOWN = 200;
    private static final int COMPLETED_COOLDOWN = 600;
    private static final int MAX_PURSUIT_TICKS = 20 * 30;
    private static final int BREAK_TICKS = 80;

    private final Raider raider;
    private ServerLevel level;
    private BlockPos target;
    private long nextSearchAt;
    private int pursuitTicks;
    private int breakTicks;

    public EmeraldChestRaidGoal(Raider raider) {
        this.raider = raider;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!(raider.level() instanceof ServerLevel serverLevel) || !raider.isAlive()) {
            return false;
        }
        long now = serverLevel.getGameTime();
        if (now < nextSearchAt) {
            return false;
        }
        nextSearchAt = now + 20L;

        BlockPos candidate = findNearestEmeraldChest(serverLevel);
        if (candidate == null) {
            return false;
        }
        if (raider.getRandom().nextFloat() >= ACQUIRE_CHANCE) {
            nextSearchAt = now + FAILED_SEARCH_COOLDOWN;
            return false;
        }

        level = serverLevel;
        target = candidate.immutable();
        return true;
    }

    private BlockPos findNearestEmeraldChest(ServerLevel serverLevel) {
        BlockPos origin = raider.blockPosition();
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;

        BlockPos min = origin.offset(-SEARCH_XZ, -SEARCH_Y, -SEARCH_XZ);
        BlockPos max = origin.offset(SEARCH_XZ, SEARCH_Y, SEARCH_XZ);
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (!serverLevel.hasChunkAt(pos)
                    || !serverLevel.getBlockState(pos).is(MoreExpandedChests.EMERALD_CHEST)) {
                continue;
            }
            double distance = raider.distanceToSqr(Vec3.atCenterOf(pos));
            if (distance < bestDistance) {
                bestDistance = distance;
                best = pos.immutable();
            }
        }
        return best;
    }

    @Override
    public void start() {
        pursuitTicks = 0;
        breakTicks = 0;
        raider.setTarget(null);
        moveTowardTarget();
    }

    @Override
    public boolean canContinueToUse() {
        return level != null
                && target != null
                && raider.isAlive()
                && pursuitTicks < MAX_PURSUIT_TICKS
                && level.getBlockState(target).is(MoreExpandedChests.EMERALD_CHEST);
    }

    @Override
    public void tick() {
        if (level == null || target == null) {
            return;
        }

        // Keep the chest as the raider's exclusive priority while this goal runs.
        raider.setTarget(null);
        pursuitTicks++;

        Vec3 center = Vec3.atCenterOf(target);
        raider.getLookControl().setLookAt(center.x, center.y, center.z);
        double distance = raider.distanceToSqr(center);
        if (distance > 5.0D) {
            if (pursuitTicks % 10 == 0 || raider.getNavigation().isDone()) {
                moveTowardTarget();
            }
            return;
        }

        raider.getNavigation().stop();
        breakTicks++;
        if (breakTicks % 10 == 1) {
            raider.swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, true);
        }
        level.destroyBlockProgress(raider.getId(), target, Math.min(9, breakTicks * 10 / BREAK_TICKS));

        if (breakTicks >= BREAK_TICKS) {
            // Clear contents before breaking so the emerald chest, its inventory,
            // and its block item are all lost as specified by the design.
            if (level.getBlockEntity(target) instanceof TieredChestBlockEntity chest) {
                chest.inventory().clearContent();
                chest.setChanged();
            }
            level.destroyBlockProgress(raider.getId(), target, -1);
            level.destroyBlock(target, false, raider);
            target = null;
            nextSearchAt = level.getGameTime() + COMPLETED_COOLDOWN;
        }
    }

    private void moveTowardTarget() {
        if (target != null) {
            raider.getNavigation().moveTo(
                    target.getX() + 0.5D,
                    target.getY() + 0.5D,
                    target.getZ() + 0.5D,
                    1.15D
            );
        }
    }

    @Override
    public void stop() {
        if (level != null && target != null) {
            level.destroyBlockProgress(raider.getId(), target, -1);
            nextSearchAt = Math.max(nextSearchAt, level.getGameTime() + 100L);
        }
        raider.getNavigation().stop();
        target = null;
        level = null;
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }
}
