package dev.moreexpandedchests;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import dev.moreexpandedchests.ai.EmeraldChestRaidGoal;
import net.minecraft.world.entity.raid.Raider;
import net.fabricmc.fabric.api.menu.v1.ExtendedMenuType;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.transfer.v1.item.ContainerStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CookingFuel;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.storage.loot.providers.number.floats.ResolvableFloat;
import net.minecraft.world.level.storage.loot.providers.number.ints.ResolvableInt;

public final class MoreExpandedChests implements ModInitializer {
    public static final String MOD_ID = "moreexpandedchests";

    // Vanilla single chest = 27 slots. Standard tiers use whole 27-slot multiples.
    // The Coal and Charcoal chests intentionally use 18 slots (2/3 chest); Amethyst uses 4.
    public static final TieredChestBlock COPPER_CHEST = registerChest("copper_chest", 54, 3.0F, true);
    public static final TieredChestBlock IRON_CHEST = registerChest("iron_chest", 81, 5.0F, true);
    public static final TieredChestBlock GOLD_CHEST = registerChest("gold_chest", 108, 5.0F, true);
    public static final TieredChestBlock DIAMOND_CHEST = registerChest("diamond_chest", 135, 6.0F, true);
    public static final TieredChestBlock NETHERITE_CHEST = registerChest("netherite_chest", 189, 50.0F, true);
    public static final TieredChestBlock GLASS_CHEST = registerChest("glass_chest", 54, 1.0F, true);
    public static final TieredChestBlock LAPIS_CHEST = registerChest("lapis_chest", 27, 3.0F, true);
    public static final TieredChestBlock COAL_CHEST = registerChest("coal_chest", 18, 3.0F, true);
    public static final TieredChestBlock CHARCOAL_CHEST = registerChest("charcoal_chest", 18, 3.0F, true);
    public static final TieredChestBlock EMERALD_CHEST = registerChest("emerald_chest", 27, 5.0F, true);
    public static final TieredChestBlock ECHO_CHEST = registerChest("echo_chest", 2700, 50.0F, true);
    public static final TieredChestBlock AMETHYST_CHEST = registerChest("amethyst_chest", 4, 3.0F, true);

    // Shared first-stage template and material-specific templates.
    public static final Item CHEST_UPGRADE_TEMPLATE = registerTemplate("chest_upgrade_template");
    public static final Item COPPER_TEMPLATE = registerTemplate("copper_chest_upgrade_template");
    public static final Item IRON_TEMPLATE = registerTemplate("iron_chest_upgrade_template");
    public static final Item GOLD_TEMPLATE = registerTemplate("gold_chest_upgrade_template");
    public static final Item DIAMOND_TEMPLATE = registerTemplate("diamond_chest_upgrade_template");
    public static final Item NETHERITE_TEMPLATE = registerTemplate("netherite_chest_upgrade_template");
    public static final Item GLASS_TEMPLATE = registerTemplate("glass_chest_upgrade_template");
    public static final Item LAPIS_TEMPLATE = registerTemplate("lapis_chest_upgrade_template");
    public static final Item COAL_TEMPLATE = registerTemplate("coal_chest_upgrade_template");
    public static final Item CHARCOAL_TEMPLATE = registerTemplate("charcoal_chest_upgrade_template");
    public static final Item EMERALD_TEMPLATE = registerTemplate("emerald_chest_upgrade_template");
    public static final Item ECHO_TEMPLATE = registerTemplate("echo_chest_upgrade_template");
    public static final Item ECHO_SHARD_BUNDLE = registerTemplate("echo_shard_bundle");
    public static final Item AMETHYST_TEMPLATE = registerTemplate("amethyst_chest_upgrade_template");

    public static final BlockEntityType<TieredChestBlockEntity> CHEST_BLOCK_ENTITY = Registry.register(
            BuiltInRegistries.BLOCK_ENTITY_TYPE,
            id("tiered_chest"),
            FabricBlockEntityTypeBuilder.create(
                    TieredChestBlockEntity::new,
                    COPPER_CHEST, IRON_CHEST, GOLD_CHEST, DIAMOND_CHEST, NETHERITE_CHEST,
                    GLASS_CHEST, LAPIS_CHEST, COAL_CHEST, CHARCOAL_CHEST, EMERALD_CHEST, ECHO_CHEST, AMETHYST_CHEST
            ).build()
    );

    public static final MenuType<TieredChestMenu> CHEST_MENU = Registry.register(
            BuiltInRegistries.MENU,
            id("tiered_chest"),
            new ExtendedMenuType<>(TieredChestMenu::new, BlockPos.STREAM_CODEC)
    );

    private static TieredChestBlock registerChest(String name, int slots, float strength, boolean fireResistant) {
        Identifier identifier = id(name);
        ResourceKey<net.minecraft.world.level.block.Block> blockKey = ResourceKey.create(Registries.BLOCK, identifier);
        BlockBehaviour.Properties blockProperties = BlockBehaviour.Properties.of()
                .setId(blockKey)
                .strength(strength)
                .requiresCorrectToolForDrops();

        TieredChestBlock block = new TieredChestBlock(blockProperties, slots, fireResistant);
        Registry.register(BuiltInRegistries.BLOCK, identifier, block);

        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, identifier);
        Item.Properties itemProperties = new Item.Properties().setId(itemKey).useBlockDescriptionPrefix();
        // Every dropped chest item is fire/lava resistant. ItemEntity damage protection also
        // covers cactus and other environmental damage (see EchoChestItemDamageMixin).
        itemProperties.fireResistant();
        if (name.equals("coal_chest") || name.equals("charcoal_chest")) {
            // Keep the original 128,000-tick fuel value on both now-distinct fuel chest items.
            // In Minecraft 26.3 the furnace reads this Data Component directly.
            itemProperties.component(DataComponents.COOKING_FUEL,
                    new CookingFuel(new ResolvableInt.Constant(128000), new ResolvableFloat.Constant(1.0F)));
        }
        Registry.register(BuiltInRegistries.ITEM, identifier, new BlockItem(block, itemProperties));
        return block;
    }

    private static Item registerTemplate(String name) {
        Identifier identifier = id(name);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, identifier);
        return Registry.register(BuiltInRegistries.ITEM, identifier, new Item(new Item.Properties().setId(key)));
    }

    public static boolean isChestItem(Item item) {
        return item == COPPER_CHEST.asItem()
                || item == IRON_CHEST.asItem()
                || item == GOLD_CHEST.asItem()
                || item == DIAMOND_CHEST.asItem()
                || item == NETHERITE_CHEST.asItem()
                || item == GLASS_CHEST.asItem()
                || item == LAPIS_CHEST.asItem()
                || item == COAL_CHEST.asItem()
                || item == CHARCOAL_CHEST.asItem()
                || item == EMERALD_CHEST.asItem()
                || item == ECHO_CHEST.asItem()
                || item == AMETHYST_CHEST.asItem();
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ItemStorage.SIDED.registerForBlockEntity(
                (blockEntity, direction) -> ContainerStorage.of(blockEntity, direction), CHEST_BLOCK_ENTITY
        );

        // Illagers occasionally acquire a top-priority objective to raid an Emerald Chest.
        ServerEntityEvents.ENTITY_LOAD.register((entity, serverLevel) -> {
            if (entity instanceof Raider raider) {
                raider.getGoalSelector().addGoal(0, new EmeraldChestRaidGoal(raider));
            }
        });

        // Coal/charcoal chests are furnace-fuel items, not flammable world blocks.
        // Storage blocks themselves are intentionally not registered as burnable.

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(output -> {
            output.accept(COPPER_CHEST);
            output.accept(IRON_CHEST);
            output.accept(GOLD_CHEST);
            output.accept(DIAMOND_CHEST);
            output.accept(NETHERITE_CHEST);
            output.accept(GLASS_CHEST);
            output.accept(LAPIS_CHEST);
            output.accept(COAL_CHEST);
            output.accept(CHARCOAL_CHEST);
            output.accept(EMERALD_CHEST);
            output.accept(ECHO_CHEST);
            output.accept(AMETHYST_CHEST);
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(output -> {
            output.accept(CHEST_UPGRADE_TEMPLATE);
            output.accept(COPPER_TEMPLATE);
            output.accept(IRON_TEMPLATE);
            output.accept(GOLD_TEMPLATE);
            output.accept(DIAMOND_TEMPLATE);
            output.accept(NETHERITE_TEMPLATE);
            output.accept(GLASS_TEMPLATE);
            output.accept(LAPIS_TEMPLATE);
            output.accept(COAL_TEMPLATE);
            output.accept(CHARCOAL_TEMPLATE);
            output.accept(EMERALD_TEMPLATE);
            output.accept(ECHO_TEMPLATE);
            output.accept(ECHO_SHARD_BUNDLE);
            output.accept(AMETHYST_TEMPLATE);
        });
        System.out.println("[More Expanded Chests] Registered twelve chest variants and their upgrade templates.");
    }
}
