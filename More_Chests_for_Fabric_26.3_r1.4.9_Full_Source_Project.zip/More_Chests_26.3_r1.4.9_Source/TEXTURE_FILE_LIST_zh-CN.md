# More Chests r1.4.1 纹理文件清单

- 铁、金、钻石、下界合金箱子：`textures/block/<material>_chest_{front,side,top,bottom}.png`，每张 4096×4096 px。
- 其余箱子及铜箱氧化阶段：当前仍为 32×32 px。
- GUI 材质边框：`textures/gui/frame_<material>.png`，208×252 px；保留中间原版 176×222 箱子面板，并在底部增加独立页码控制带。
- 模组图标：`moreexpandedchests_icon.png`，128×128 px。

4K 纹理通过最近邻放大保留原始 32×32 像素图案，当前属于分辨率适配版，不代表已完成逐像素重绘的高细节新纹理。
