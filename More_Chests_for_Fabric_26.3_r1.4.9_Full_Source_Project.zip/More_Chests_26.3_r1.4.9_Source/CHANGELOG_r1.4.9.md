# More Chests r1.4.9 — gameplay and compact GUI revision

## Implemented in source
- Added a distinct 18-slot Charcoal Chest and charcoal-only storage rule; Coal Chest is now coal-only.
- Both fuel chests retain the 128,000-tick `minecraft:cooking_fuel` component.
- Removed world-block flammability registration; chest block items are fire-resistant.
- Added item-entity damage protection for all twelve mod chest items.
- Echo Chest void protection now only recovers the item entity at 30 blocks below minimum Y. Generic `Entity.remove` cancellation was removed so deliberate trash/creative clear/discard actions are permitted.
- Echo Chest drops require an actual Netherite Pickaxe; its vanilla diamond-tier tag remains for normal pickaxe harvest behavior.
- Standard storage tiers use 27-slot multiples; Glass Chest is 54, Coal/Charcoal are 18 each, and Amethyst remains 4.
- Chest GUI row count follows the actual container size; the oversize material frame was removed; all three controls are 20×20; paging controls sit in a separate strip below the vanilla panel. The vanilla `generic_54` background is drawn in two sections so the 96px player inventory background follows the real chest row count rather than remaining at the six-row texture offset.
- r2 32×32 face textures were wired into the model paths. All block-model UV coordinates were doubled from 0–16 to 0–32, so the full 32×32 textures are sampled.
- Added vanilla chest/trapped-chest/barrel axe mining tag; all mod chests are pickaxe-minable with material tier tags.

## Validation boundary
- JSON/resource references, texture dimensions, model UV ranges, recipe/tag coverage, gameplay source invariants, GUI structure and ZIP integrity are checked by `tools/validate_project.py` (101 checks passed).
- Java 25 compilation and Minecraft 26.3 in-game testing are not run in this environment (available runtime is Java 21 and no Gradle installation/wrapper is present).
