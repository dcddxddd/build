# r1.2.9 - 箱子纹理全面重制

- 重新绘制 11 种箱子的 front/side/top/bottom 方块贴图。
- 物品栏箱子图标重制为带阴影、透视侧面、箱盖分层和材质徽章的 32×32 像素图。
- 重新着色 11 套 GUI 边框，使边缘色彩与箱体材质一致。
- 铜箱保留 4 阶氧化外观，分别提供 front/side/top/bottom。
- 新增 CHEST_TEXTURES_PREVIEW.png、TEXTURE_FILE_LIST_zh-CN.md 和 TEXTURE_VALIDATION.txt。
