# 用户提供的 26.3 编译排错记录并入情况

以下迁移点已经在当前源码中核对：

- `Level.isClientSide()` 方法调用：源码没有残留 `isClientSide` 字段式访问。
- 玻璃箱 ItemStack 编码：使用 `ItemStack.CODEC` 和 `NbtOps`；r1.2.8 另加空栈与 `DataResult` 安全处理。
- `EchoChestSavedData`：遍历 `ItemStackTemplate`，调用 `create()` 再保存到物品列表。
- `TieredChestBlock.codec()`：使用 `MapCodec.unit(...)`。
- `TieredChestBlock.playerWillDestroy(...)`：返回 `BlockState` 并返回父类结果。
- 灾厄村民搜索范围：使用 `BlockPos.betweenClosed(min, max)`。
- 灾厄村民挥手：使用 `swing(InteractionHand.MAIN_HAND, SwingAnimation.DEFAULT, true)`。
- 玻璃箱旋转：使用 JOML `Matrix4f` 传入 `PoseStack.mulPose(...)`。

这些源码静态核对不等于本执行环境重新编译成功。用户记录中的 `BUILD SUCCESSFUL` 是其本地 r1.2.5 构建记录；r1.2.8 的实际构建仍需 JDK 25 / Gradle 9.9 环境重新执行。
