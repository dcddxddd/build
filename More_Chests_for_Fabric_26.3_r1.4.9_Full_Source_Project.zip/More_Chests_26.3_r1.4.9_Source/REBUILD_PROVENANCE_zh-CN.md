# More Expanded Chests 源码重建说明

## 本包来源

本包以资料库中可正常解压的 `MoreExpandedChests_26.3_Fabric_r1.3.0_source.zip` 为唯一源码基线。该 ZIP 已通过完整 CRC 测试。另行核对了资料库中的 r1.2.9 源码包；其 ZIP CRC 测试也通过，用作历史版本对照。

## r1.4.0 资料处理

资料库中的 `MoreExpandedChests_26.3_Fabric_r1.4.0_source.zip` 实际大小为 15,728,640 字节，缺少 ZIP 中央目录和 EOCD 结束记录，无法可靠解压，因此没有从该压缩包提取或覆盖任何 Java、JSON、Gradle 或资源文件。

资料库仍保留 r1.4.0 的静态检查报告以及两张预览图。本包附带两张预览图作为设计参考：
- `REFERENCE_CHEST_ATLAS_PREVIEW_r1.4.0.png`
- `REFERENCE_TEMPLATE_ICONS_PREVIEW_r1.4.0.png`

注意：第一张是 820×900 的展示预览图，不是游戏内 4096×4096 材质源图；不能将它误认为已经加入项目的 4K 纹理资源。r1.4.0 报告中的代码改动也不能仅凭报告视为已恢复。

## 当前源码版本

- Fabric mod id：`moreexpandedchests`
- Minecraft：26.3
- Java：25+
- Gradle project version：1.3.0
- 本包是 r1.3.0 源码的完整性重建归档，不宣称实现了 r1.4.0 报告中列出的全部功能。

## 验证边界

本次重建执行了项目自带的 `tools/validate_project.py`、JSON 解析、资源引用检查、ZIP CRC 测试和二次解压核对。当前运行环境不具备 Java 25 与 Gradle 构建环境，因此未声称 Java 编译通过，也未声称完成 Minecraft 26.3 实机测试。
