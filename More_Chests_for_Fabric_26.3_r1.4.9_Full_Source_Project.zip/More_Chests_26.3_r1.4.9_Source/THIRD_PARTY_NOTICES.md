Third-party source and license notices

Advanced Storage Chests (Fabric)
https://github.com/xHeaVeNxyz/advanced-storage-chests
Copyright (c) 2026 HeaVeNxyz
License: MIT

This project adapts the upstream paged chest menu, double-chest inventory model, page synchronization approach, and Fabric Transfer API integration. The upstream MIT license is preserved in LICENSE.
