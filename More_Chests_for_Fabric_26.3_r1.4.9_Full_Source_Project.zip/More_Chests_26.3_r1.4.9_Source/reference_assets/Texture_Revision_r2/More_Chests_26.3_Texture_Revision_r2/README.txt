More Chests for Fabric 26.3 — texture revision r2

Contents
- 56 individual 32x32 RGBA PNGs
- 14 material rows: copper oxidation stages 0-3, iron, gold, diamond, netherite, glass, lapis, coal, emerald, echo, amethyst
- 4 face textures per material: front, side, top, bottom
- chest_faces_atlas_128x448.png: unlabeled 4x14 atlas
- texture_preview.png: labeled preview sheet

What changed from the previous concept set
- Front latch is smaller and centered, with a consistent horizontal lid seam.
- Side textures use continuous, simpler board bands to reduce visible repetition when UVs stretch.
- Top and bottom use a restrained square inset motif.
- Colors are slightly brighter and less flat to remain legible under Minecraft world lighting.
- All non-glass faces are fully opaque. Glass is only subtly translucent (alpha 224); echo is opaque dark teal rather than a nearly invisible particle-like surface.
- All images are nearest-neighbour resampled to preserve pixel edges.

Important integration note
This folder is a revised artwork pack, not a drop-in resource pack or compiled mod. The previous pack used conceptual paths under assets/moreexpandedchests/textures/block/<material>/<face>.png. The supplied in-game screenshot shows that the live renderer/model mapping does not yet correspond reliably to that concept sheet. To fix the actual in-game appearance, the matching 1.4.7 runtime JAR or complete source project must be inspected so these 56 textures can be mapped to the exact texture identifiers and UV regions used by its block models/block-entity renderer. Do not rename or copy these files into the live mod blindly.
